// Coordinate definitions
const points = {
    A: { x: 0, y: 5 },
    B: { x: 0, y: 2 },
    C: { x: 0, y: 0 },
    D: { x: 2, y: 5 },
    E: { x: 2, y: 2 },
    F: { x: 2, y: 0 },
    G: { x: 7, y: 5 },
    H: { x: 7, y: 2 },
    I: { x: 7, y: 0 },
  };
  
  // Connection definitions
  const connections = {
    A: ['B', 'D'],
    B: ['A', 'C', 'E'],
    C: ['B', 'F'],
    D: ['A', 'E'],
    E: ['B', 'D', 'F', 'H'],
    F: ['C', 'E', 'I'],
    G: ['H'],
    H: ['G', 'E', 'I'],
    I: ['F', 'H'],
  };
  
  // Calculate Euclidean distance between two points
  function distance(p1, p2) {
    return Math.hypot(p1.x - p2.x, p1.y - p2.y);
  }
  
  // Generate weighted graph
  function generateGraph(coords, edges) {
    const graph = {};
    for (let node in edges) {
      graph[node] = {};
      for (let neighbor of edges[node]) {
        graph[node][neighbor] = distance(coords[node], coords[neighbor]);
      }
    }
    return graph;
  }
  
  // Dijkstra's algorithm
  function dijkstra(graph, start, end) {
    const dist = {}, prev = {}, visited = new Set();
    const pq = new Map(Object.keys(graph).map(k => [k, Infinity]));
    dist[start] = 0;
    pq.set(start, 0);
  
    while (pq.size) {
      const [current] = [...pq.entries()].reduce((a, b) => a[1] < b[1] ? a : b);
      pq.delete(current);
      if (current === end) break;
  
      for (let neighbor in graph[current]) {
        if (visited.has(neighbor)) continue;
        const alt = dist[current] + graph[current][neighbor];
        if (alt < (dist[neighbor] ?? Infinity)) {
          dist[neighbor] = alt;
          prev[neighbor] = current;
          pq.set(neighbor, alt);
        }
      }
      visited.add(current);
    }
  
    const path = [];
    for (let at = end; at; at = prev[at]) path.unshift(at);
    return path.length ? path : null;
  }
  
  // Get step-by-step coordinates between two points on a grid
  function getStepsBetween(p1, p2) {
    const path = [];
    let x = p1.x, y = p1.y;
  
    const dx = Math.sign(p2.x - p1.x);
    const dy = Math.sign(p2.y - p1.y);
  
    while (x !== p2.x || y !== p2.y) {
      if (x !== p2.x) x += dx;
      else if (y !== p2.y) y += dy;
  
      path.push({ x, y });
    }
  
    return path;
  }
  
  // Main function to get full coordinate path
  function getShortestPath(start, end) {
    const graph = generateGraph(points, connections);
    const path = dijkstra(graph, start, end);
  
    if (!path) {
      console.log(`No path from ${start} to ${end}`);
      return null;
    }
  
    const coordinates = path.map(p => points[p]);
  
    const fullPath = [coordinates[0]];
    for (let i = 0; i < coordinates.length - 1; i++) {
      const steps = getStepsBetween(coordinates[i], coordinates[i + 1]);
      fullPath.push(...steps);
    }
  
    console.log(`Shortest path from ${start} to ${end}:`);
    fullPath.forEach(c => console.log(`(${c.x}, ${c.y})`));
  
    return fullPath;
  }
  
  // 🧪 Test example
  getShortestPath('A', 'H');
  