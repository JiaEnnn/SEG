function updateSeveritySlider(slider) {
    const val = parseInt(slider.value);
    let percent = 0;
    let color = "#ddd"; // Default grey (no severity)
  
    if (val === 2) {
      percent = 33;
      color = "#6c63ff"; // Blue - Info
    } else if (val === 3) {
      percent = 66;
      color = "#ff9800"; // Orange - Warning
    } else if (val === 4) {
      percent = 99;
      color = "#dc3545"; // Red - Danger
    }
  
    slider.style.background = `linear-gradient(to right, ${color} ${percent}%, #ddd ${percent}%)`;
  }

  document.getElementById("alertForm").addEventListener("submit", async function (e) {
    e.preventDefault(); // prevent default form action
  
    const alertData = {
      title: document.getElementById("alertTitle").value,
      description: document.getElementById("description").value,
      severity: document.getElementById("severitySlider").value,
      zone: document.getElementById("zone").value,
      // optionally add time: new Date().toISOString() or from a datetime input
    };
  
    try {
      const res = await fetch("http://your-server-url/api/alerts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(alertData),
      });
  
      if (res.ok) {
        alert("Alert published successfully!");
        window.location.href = "emergency.html"; // redirect or reload
      } else {
        alert("Failed to publish alert.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Error occurred while publishing alert.");
    }
  });
  
  