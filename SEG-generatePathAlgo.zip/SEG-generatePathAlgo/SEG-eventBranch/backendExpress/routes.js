const express = require('express');
const router = express.Router();
const db = require('./connectDB'); // Import database connection

// Define the route
router.get('/api/your-endpoint', (req, res) => {
    res.json({ message: "API is working!" });
});

// Route: GET /database - Retrieve all users
router.get('/database', (req, res) => {
    const query = `
        SELECT userID, userType, email, number, createdAt, updatedAt, lastLoginDate 
        FROM users;
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Route: GET /all-tables - Get all tables separately
router.get('/all-tables', (req, res) => {
    const queries = {
        users: 'SELECT * FROM users',
        students: 'SELECT * FROM students',
        staff: 'SELECT * FROM staff',
        admins: 'SELECT * FROM admins',
        classrooms: 'SELECT * FROM classrooms',
        facilities: 'SELECT * FROM facilities',
        special_coordinates: 'SELECT * special_coordinates',
        paths: 'SELECT * FROM paths',
        emergency_routes: 'SELECT * FROM emergency_routes',
        buildings: 'SELECT * FROM buildings'
    };

    let responseData = {};
    let queryPromises = Object.keys(queries).map(table => {
        return new Promise((resolve, reject) => {
            db.query(queries[table], (err, results) => {
                if (err) return reject(err);
                responseData[table] = results;
                resolve();
            });
        });
    });

    Promise.all(queryPromises)
        .then(() => res.json(responseData))
        .catch(err => res.status(500).json({ error: err.message }));
});

// Update user language (moved to settings_preferences)
router.post('/update-language', (req, res) => {
    const { id, language } = req.body;
    if (!id || !language) return res.status(400).json({ error: "Missing required fields" });
    
    const query = `UPDATE settings_preferences SET language = ? WHERE userID = ?`;
    db.query(query, [language, id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Language updated successfully" });
    });
});

// Get user language
router.get('/get-language/:id', (req, res) => {
    const { id } = req.params;
    const query = `SELECT language FROM settings_preferences WHERE userID = ?`;
    
    db.query(query, [id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: "User not found" });
        res.json({ language: results[0].language });
    });
});

// Get search history
router.get('/search-history/:id', (req, res) => {
    const { id } = req.params;
    const query = `SELECT * FROM search_history WHERE userID = ? ORDER BY search_date DESC`;
    
    db.query(query, [id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Get all buildings
router.get('/buildings', (req, res) => {
    const query = 'SELECT * FROM buildings';
    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Get all facilities
router.get('/facilities', (req, res) => {
    const query = 'SELECT * FROM facilities';
    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});





// Route: GET /classroom/:id - Fetch classroom coordinates when clicked
router.get('/classroom/:id', (req, res) => {
    const { id } = req.params;
    const query = `SELECT classroomID, room_number, building_name, floor_number, x_min, y_min, x_max, y_max FROM classrooms WHERE classroomID = ?`;
    
    db.query(query, [id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: "Classroom not found" });
        res.json(results[0]);
    });
});

// Route: GET /facility/:id - Fetch facility coordinates when clicked
router.get('/facility/:id', (req, res) => {
    const { id } = req.params;
    const query = `SELECT facilityID, facility_number, type, building_name, floor_number, x_min, y_min, x_max, y_max FROM facilities WHERE facilityID = ?`;
    
    db.query(query, [id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: "Facility not found" });
        res.json(results[0]);
    });
});

// Route: POST /special-coordinates - Fetch special coordinates when start and end are confirmed
router.post('/special-coordinates', (req, res) => {
    const { startID, endID } = req.body;
    if (!startID || !endID) return res.status(400).json({ error: "Missing required fields" });
    
    const query = `
        SELECT coordinateID, classroomID, facilityID, x_coordinate, y_coordinate 
        FROM special_coordinates
        WHERE classroomID IN (?, ?) OR facilityID IN (?, ?)
    `;
    
    db.query(query, [startID, endID, startID, endID], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Route: GET /all-special-coordinates
router.get('/all-special-coordinates', (req, res) => {
    const query = `SELECT coordinateID, x_coordinate, y_coordinate FROM special_coordinates`;
    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});



// Route: GET /path-coordinates - Fetch path coordinates (for path lighting up)
router.get('/path-coordinates', (req, res) => {
    const query = `SELECT pathID, building_name, floor_number, x_coordinate, y_coordinate FROM paths`;
    
    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

module.exports = router;
