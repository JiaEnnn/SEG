const fetch = require('node-fetch');
// Fetch coordinates from the database
async function fetchCoordinates() {
    const res = await fetch('http://localhost:5000/all-special-coordinates');
    const data = await res.json();
    const points = {};
  
    data.forEach(coord => {
      points[coord.coordinateID] = {
        x: coord.x_coordinate,
        y: coord.y_coordinate
      };
    });
  
    return points;
  }
  
  function generateConnections(points) {
    const keys = Object.keys(points);
    const connections = {};
  
    for (let i = 0; i < keys.length; i++) {
      connections[keys[i]] = [];
      for (let j = 0; j < keys.length; j++) {
        if (i !== j) {
          connections[keys[i]].push(keys[j]);
        }
      }
    }
  
    return connections;
  }
  
  function distance(p1, p2) {
    return Math.hypot(p1.x - p2.x, p1.y - p2.y);
  }
  
  function generateGraph(coords, edges) {
    const graph = {};
    for (let node in edges) {
      graph[node] = {};
      for (let neighbor of edges[node]) {
        graph[node][neighbor] = distance(coords[node], coords[neighbor]);
      }
    }
    return graph;
  }
  
  function dijkstra(graph, start, end) {
    const dist = {}, prev = {}, visited = new Set();
    const pq = new Map(Object.keys(graph).map(k => [k, Infinity]));
    dist[start] = 0;
    pq.set(start, 0);
  
    while (pq.size) {
      const [current] = [...pq.entries()].reduce((a, b) => a[1] < b[1] ? a : b);
      pq.delete(current);
      if (current === end) break;
  
      for (let neighbor in graph[current]) {
        if (visited.has(neighbor)) continue;
        const alt = dist[current] + graph[current][neighbor];
        if (alt < (dist[neighbor] ?? Infinity)) {
          dist[neighbor] = alt;
          prev[neighbor] = current;
          pq.set(neighbor, alt);
        }
      }
      visited.add(current);
    }
  
    const path = [];
    for (let at = end; at; at = prev[at]) path.unshift(at);
    return path.length ? path : null;
  }
  
  function getStepsBetween(p1, p2) {
    const path = [];
    let x = p1.x, y = p1.y;
    const dx = Math.sign(p2.x - p1.x);
    const dy = Math.sign(p2.y - p1.y);
  
    while (x !== p2.x || y !== p2.y) {
      if (x !== p2.x) x += dx;
      else if (y !== p2.y) y += dy;
      path.push({ x, y });
    }
  
    return path;
  }
  
  // MAIN FUNCTION
  async function getShortestPath(startID, endID) {
    const points = await fetchCoordinates();
    const connections = generateConnections(points); // Replace with real edges if available
    const graph = generateGraph(points, connections);
  
    const path = dijkstra(graph, startID.toString(), endID.toString());
    if (!path) {
      console.log(`No path found from ${startID} to ${endID}`);
      return null;
    }
  
    const coordinates = path.map(id => points[id]);
    const fullPath = [coordinates[0]];
  
    for (let i = 0; i < coordinates.length - 1; i++) {
      const steps = getStepsBetween(coordinates[i], coordinates[i + 1]);
      fullPath.push(...steps);
    }
  
    console.log(`Shortest path from ${startID} to ${endID}:`);
    fullPath.forEach(c => console.log(`(${c.x}, ${c.y})`));
    return fullPath;
  }
  
  getShortestPath(33310, 33321);
  