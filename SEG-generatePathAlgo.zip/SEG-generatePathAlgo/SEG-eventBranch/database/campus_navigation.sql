-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2025 at 02:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `campus_navigation`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `adminID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `permissions` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `buildings`
--

CREATE TABLE `buildings` (
  `buildingID` int(11) NOT NULL,
  `building_name` varchar(100) NOT NULL,
  `total_floors` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `classrooms`
--

CREATE TABLE `classrooms` (
  `classroomID` int(11) NOT NULL,
  `room_number` varchar(50) NOT NULL,
  `building_name` varchar(100) NOT NULL,
  `floor_number` int(11) NOT NULL,
  `x_min` int(11) NOT NULL,
  `y_min` int(11) NOT NULL,
  `x_max` int(11) NOT NULL,
  `y_max` int(11) NOT NULL,
  `room_type` enum('lecture room','lab','workshop/studio') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classrooms`
--

INSERT INTO `classrooms` (`classroomID`, `room_number`, `building_name`, `floor_number`, `x_min`, `y_min`, `x_max`, `y_max`, `room_type`) VALUES
(3000, '3R VOID', '3R Building', 3, 12, 24, 25, 30, ''),
(3001, '3R Entrance Lobby', '3R Building', 3, 0, 42, 3, 47, ''),
(3002, '3R002 Lecture Room', '3R Building', 3, 25, 31, 30, 35, 'lecture room'),
(3003, '3R003 Lecture Room', '3R Building', 3, 18, 31, 24, 35, 'lecture room'),
(3004, '3R004 Lecture Room', '3R Building', 3, 12, 31, 17, 35, 'lecture room'),
(3005, '3R005 Lecture Room', '3R Building', 3, 6, 28, 11, 35, 'lecture room'),
(3006, '3R006 Lecture Room', '3R Building', 3, 0, 36, 3, 41, 'lecture room'),
(3008, '3R008', '3R Building', 3, 4, 44, 7, 47, 'lecture room'),
(3009, '3R009 Lecture Room', '3R Building', 3, 5, 37, 11, 42, 'lecture room'),
(3010, '3R010 Mechanical Workshop', '3R Building', 3, 8, 44, 20, 49, 'workshop/studio'),
(3011, '3R011 Lecture Room', '3R Building', 3, 12, 37, 17, 42, 'lecture room'),
(3012, '3R012 Green Engineering Laboratory', '3R Building', 3, 21, 44, 33, 49, 'lab'),
(3013, '3R013 Materials & Structures Laboratory', '3R Building', 3, 18, 37, 30, 42, 'lab'),
(3014, '3R014 Aerospace Laboratory', '3R Building', 3, 34, 44, 46, 49, 'lab'),
(3015, '3R015 Design Studio', '3R Building', 3, 38, 31, 44, 42, 'workshop/studio'),
(3016, '3R016 Thermodynamics Laboratory', '3R Building', 3, 47, 44, 57, 49, 'lab'),
(3017, '3R017 Lecture Room', '3R Building', 3, 45, 37, 57, 42, 'lecture room'),
(3018, '3R018 Lecture Room', '3R Building', 3, 62, 31, 68, 35, 'lecture room'),
(3019, '3R019 Lecture Room', '3R Building', 3, 45, 31, 57, 36, 'lecture room'),
(3020, '3R020 Lecture Room', '3R Building', 3, 45, 21, 57, 26, 'lecture room'),
(3021, '3R021 Lecture Room', '3R Building', 3, 62, 26, 68, 30, 'lecture room'),
(3022, '3R022 Lecture Room', '3R Building', 3, 62, 20, 68, 25, 'lecture room'),
(3023, '3R023 Computer Science Laboratory', '3R Building', 3, 45, 12, 57, 20, 'lab'),
(3024, '3R024 Lecture Room', '3R Building', 3, 62, 15, 68, 19, 'lecture room'),
(3025, '3R025 Lecture Room', '3R Building', 3, 62, 10, 68, 14, 'lecture room'),
(3026, '3R026 Lecture Hall', '3R Building', 3, 35, 0, 48, 9, 'lecture room'),
(3027, '3R027 Computer Science Laboratory', '3R Building', 3, 35, 12, 44, 16, 'lab'),
(3028, '3R028 Computer Science Laboratory', '3R Building', 3, 35, 17, 44, 20, 'lab'),
(3030, '3R030 Lecture Room', '3R Building', 3, 21, 6, 27, 12, 'lecture room'),
(3031, '3R031 Lecture Room', '3R Building', 3, 21, 13, 27, 16, 'lecture room'),
(3032, '3R032 Engineering Foundation Laboratory', '3R Building', 3, 12, 18, 26, 23, 'lab'),
(3033, '3R033 Engineering Foundation Laboratory 3', '3R Building', 3, 13, 7, 20, 16, 'lab'),
(3034, '3R034 Engineering Foundation Laboratory 3', '3R Building', 3, 5, 7, 12, 16, 'lab'),
(3036, '3R036 Lobby', '3R Building', 3, 5, 17, 11, 27, ''),
(3041, '3R041 Lobby', '3R Building', 3, 58, 46, 68, 49, '');

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE `facilities` (
  `facilityID` int(11) NOT NULL,
  `facility_number` varchar(50) NOT NULL,
  `type` enum('toilet','lift','emergency_exit','surau') NOT NULL,
  `building_name` varchar(100) NOT NULL,
  `floor_number` int(11) NOT NULL,
  `x_min` int(11) NOT NULL,
  `x_max` int(11) NOT NULL,
  `y_min` int(11) NOT NULL,
  `y_max` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`facilityID`, `facility_number`, `type`, `building_name`, `floor_number`, `x_min`, `x_max`, `y_min`, `y_max`) VALUES
(3200, '3R OKU Toilet', 'toilet', '3R Building', 3, 66, 68, 36, 37),
(3201, '3R Right Female Toilet', 'toilet', '3R Building', 3, 66, 68, 38, 40),
(3202, '3R Right Male Toilet', 'toilet', '3R Building', 3, 66, 68, 41, 43),
(3203, '3R Toilets Bottom Left', 'toilet', '3R Building', 3, 13, 16, 0, 4),
(3211, '3R Emergency Exit B', 'emergency_exit', '3R Building', 3, 31, 34, 0, 4),
(3223, '3R Lift Lobby', 'lift', '3R Building', 3, 17, 30, 0, 4),
(3233, '3R Staircase', 'emergency_exit', '3R Building', 3, 26, 30, 24, 30),
(3235, '3R035 Male Surau', 'surau', '3R Building', 3, 5, 12, 0, 6);

-- --------------------------------------------------------

--
-- Table structure for table `paths`
--

CREATE TABLE `paths` (
  `pathID` int(11) NOT NULL,
  `building_name` varchar(100) NOT NULL,
  `floor_number` int(11) NOT NULL,
  `x_coordinate` int(11) NOT NULL,
  `y_coordinate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paths`
--

INSERT INTO `paths` (`pathID`, `building_name`, `floor_number`, `x_coordinate`, `y_coordinate`) VALUES
(1, '3R Building', 3, 4, 43),
(2, '3R Building', 3, 5, 43),
(3, '3R Building', 3, 6, 43),
(4, '3R Building', 3, 7, 43),
(5, '3R Building', 3, 8, 43),
(6, '3R Building', 3, 9, 43),
(7, '3R Building', 3, 10, 43),
(8, '3R Building', 3, 11, 43),
(9, '3R Building', 3, 12, 43),
(10, '3R Building', 3, 13, 43),
(11, '3R Building', 3, 14, 43),
(12, '3R Building', 3, 15, 43),
(13, '3R Building', 3, 16, 43),
(14, '3R Building', 3, 17, 43),
(15, '3R Building', 3, 18, 43),
(16, '3R Building', 3, 19, 43),
(17, '3R Building', 3, 20, 43),
(18, '3R Building', 3, 21, 43),
(19, '3R Building', 3, 22, 43),
(20, '3R Building', 3, 23, 43),
(21, '3R Building', 3, 24, 43),
(22, '3R Building', 3, 25, 43),
(23, '3R Building', 3, 26, 43),
(24, '3R Building', 3, 27, 43),
(25, '3R Building', 3, 28, 43),
(26, '3R Building', 3, 29, 43),
(27, '3R Building', 3, 30, 43),
(28, '3R Building', 3, 31, 43),
(29, '3R Building', 3, 32, 43),
(30, '3R Building', 3, 33, 43),
(31, '3R Building', 3, 34, 43),
(32, '3R Building', 3, 35, 43),
(33, '3R Building', 3, 36, 43),
(34, '3R Building', 3, 37, 43),
(35, '3R Building', 3, 38, 43),
(36, '3R Building', 3, 39, 43),
(37, '3R Building', 3, 40, 43),
(38, '3R Building', 3, 41, 43),
(39, '3R Building', 3, 42, 43),
(40, '3R Building', 3, 43, 43),
(41, '3R Building', 3, 44, 43),
(42, '3R Building', 3, 45, 43),
(43, '3R Building', 3, 46, 43),
(44, '3R Building', 3, 47, 43),
(45, '3R Building', 3, 48, 43),
(46, '3R Building', 3, 49, 43),
(47, '3R Building', 3, 50, 43),
(48, '3R Building', 3, 51, 43),
(49, '3R Building', 3, 52, 43),
(50, '3R Building', 3, 53, 43),
(51, '3R Building', 3, 54, 43),
(52, '3R Building', 3, 55, 43),
(53, '3R Building', 3, 56, 43),
(54, '3R Building', 3, 57, 43),
(55, '3R Building', 3, 58, 43),
(56, '3R Building', 3, 59, 43),
(57, '3R Building', 3, 60, 43),
(58, '3R Building', 3, 61, 43),
(59, '3R Building', 3, 62, 43),
(60, '3R Building', 3, 63, 43),
(61, '3R Building', 3, 64, 43),
(62, '3R Building', 3, 65, 43),
(63, '3R Building', 3, 58, 44),
(64, '3R Building', 3, 59, 44),
(65, '3R Building', 3, 60, 44),
(66, '3R Building', 3, 58, 45),
(67, '3R Building', 3, 59, 45),
(68, '3R Building', 3, 60, 45),
(69, '3R Building', 3, 58, 36),
(70, '3R Building', 3, 59, 36),
(71, '3R Building', 3, 60, 36),
(72, '3R Building', 3, 61, 36),
(73, '3R Building', 3, 62, 36),
(74, '3R Building', 3, 63, 36),
(75, '3R Building', 3, 64, 36),
(76, '3R Building', 3, 65, 36),
(77, '3R Building', 3, 58, 37),
(78, '3R Building', 3, 59, 37),
(79, '3R Building', 3, 60, 37),
(80, '3R Building', 3, 61, 37),
(81, '3R Building', 3, 62, 37),
(82, '3R Building', 3, 63, 37),
(83, '3R Building', 3, 64, 37),
(84, '3R Building', 3, 65, 37),
(85, '3R Building', 3, 58, 38),
(86, '3R Building', 3, 59, 38),
(87, '3R Building', 3, 60, 38),
(88, '3R Building', 3, 61, 38),
(89, '3R Building', 3, 62, 38),
(90, '3R Building', 3, 63, 38),
(91, '3R Building', 3, 64, 38),
(92, '3R Building', 3, 65, 38),
(93, '3R Building', 3, 58, 39),
(94, '3R Building', 3, 59, 39),
(95, '3R Building', 3, 60, 39),
(96, '3R Building', 3, 61, 39),
(97, '3R Building', 3, 62, 39),
(98, '3R Building', 3, 63, 39),
(99, '3R Building', 3, 64, 39),
(100, '3R Building', 3, 65, 39),
(101, '3R Building', 3, 58, 40),
(102, '3R Building', 3, 59, 40),
(103, '3R Building', 3, 60, 40),
(104, '3R Building', 3, 61, 40),
(105, '3R Building', 3, 62, 40),
(106, '3R Building', 3, 63, 40),
(107, '3R Building', 3, 64, 40),
(108, '3R Building', 3, 65, 40),
(109, '3R Building', 3, 58, 41),
(110, '3R Building', 3, 59, 41),
(111, '3R Building', 3, 60, 41),
(112, '3R Building', 3, 61, 41),
(113, '3R Building', 3, 62, 41),
(114, '3R Building', 3, 63, 41),
(115, '3R Building', 3, 64, 41),
(116, '3R Building', 3, 65, 41),
(117, '3R Building', 3, 58, 42),
(118, '3R Building', 3, 59, 42),
(119, '3R Building', 3, 60, 42),
(120, '3R Building', 3, 61, 42),
(121, '3R Building', 3, 62, 42),
(122, '3R Building', 3, 63, 42),
(123, '3R Building', 3, 64, 42),
(124, '3R Building', 3, 65, 42),
(125, '3R Building', 3, 58, 10),
(126, '3R Building', 3, 58, 11),
(127, '3R Building', 3, 58, 12),
(128, '3R Building', 3, 58, 13),
(129, '3R Building', 3, 58, 14),
(130, '3R Building', 3, 58, 15),
(131, '3R Building', 3, 58, 16),
(132, '3R Building', 3, 58, 17),
(133, '3R Building', 3, 58, 18),
(134, '3R Building', 3, 58, 19),
(135, '3R Building', 3, 58, 20),
(136, '3R Building', 3, 58, 21),
(137, '3R Building', 3, 58, 22),
(138, '3R Building', 3, 58, 23),
(139, '3R Building', 3, 58, 24),
(140, '3R Building', 3, 58, 25),
(141, '3R Building', 3, 58, 26),
(142, '3R Building', 3, 58, 27),
(143, '3R Building', 3, 58, 28),
(144, '3R Building', 3, 58, 29),
(145, '3R Building', 3, 58, 30),
(146, '3R Building', 3, 58, 31),
(147, '3R Building', 3, 58, 32),
(148, '3R Building', 3, 58, 33),
(149, '3R Building', 3, 58, 34),
(150, '3R Building', 3, 58, 35),
(151, '3R Building', 3, 59, 10),
(152, '3R Building', 3, 59, 35),
(153, '3R Building', 3, 60, 10),
(154, '3R Building', 3, 60, 35),
(155, '3R Building', 3, 61, 10),
(156, '3R Building', 3, 61, 35),
(157, '3R Building', 3, 28, 10),
(158, '3R Building', 3, 29, 10),
(159, '3R Building', 3, 30, 10),
(160, '3R Building', 3, 31, 10),
(161, '3R Building', 3, 32, 10),
(162, '3R Building', 3, 33, 10),
(163, '3R Building', 3, 34, 10),
(164, '3R Building', 3, 35, 10),
(165, '3R Building', 3, 36, 10),
(166, '3R Building', 3, 37, 10),
(167, '3R Building', 3, 38, 10),
(168, '3R Building', 3, 39, 10),
(169, '3R Building', 3, 40, 10),
(170, '3R Building', 3, 41, 10),
(171, '3R Building', 3, 42, 10),
(172, '3R Building', 3, 43, 10),
(173, '3R Building', 3, 44, 10),
(174, '3R Building', 3, 45, 10),
(175, '3R Building', 3, 46, 10),
(176, '3R Building', 3, 47, 10),
(177, '3R Building', 3, 48, 10),
(178, '3R Building', 3, 49, 10),
(179, '3R Building', 3, 50, 10),
(180, '3R Building', 3, 51, 10),
(181, '3R Building', 3, 52, 10),
(182, '3R Building', 3, 53, 10),
(183, '3R Building', 3, 54, 10),
(184, '3R Building', 3, 55, 10),
(185, '3R Building', 3, 56, 10),
(186, '3R Building', 3, 57, 10),
(187, '3R Building', 3, 28, 11),
(188, '3R Building', 3, 57, 11),
(189, '3R Building', 3, 28, 5),
(190, '3R Building', 3, 28, 6),
(191, '3R Building', 3, 28, 7),
(192, '3R Building', 3, 28, 8),
(193, '3R Building', 3, 28, 9),
(194, '3R Building', 3, 28, 10),
(195, '3R Building', 3, 28, 11),
(196, '3R Building', 3, 28, 12),
(197, '3R Building', 3, 28, 13),
(198, '3R Building', 3, 28, 14),
(199, '3R Building', 3, 28, 15),
(200, '3R Building', 3, 28, 16),
(201, '3R Building', 3, 28, 17),
(202, '3R Building', 3, 29, 5),
(203, '3R Building', 3, 29, 17),
(204, '3R Building', 3, 30, 5),
(205, '3R Building', 3, 30, 17),
(206, '3R Building', 3, 31, 5),
(207, '3R Building', 3, 31, 17),
(208, '3R Building', 3, 32, 5),
(209, '3R Building', 3, 32, 17),
(210, '3R Building', 3, 33, 5),
(211, '3R Building', 3, 33, 17),
(212, '3R Building', 3, 34, 5),
(213, '3R Building', 3, 34, 17),
(214, '3R Building', 3, 13, 5),
(215, '3R Building', 3, 14, 5),
(216, '3R Building', 3, 15, 5),
(217, '3R Building', 3, 16, 5),
(218, '3R Building', 3, 17, 5),
(219, '3R Building', 3, 18, 5),
(220, '3R Building', 3, 19, 5),
(221, '3R Building', 3, 20, 5),
(222, '3R Building', 3, 21, 5),
(223, '3R Building', 3, 22, 5),
(224, '3R Building', 3, 23, 5),
(225, '3R Building', 3, 24, 5),
(226, '3R Building', 3, 25, 5),
(227, '3R Building', 3, 26, 5),
(228, '3R Building', 3, 27, 5),
(229, '3R Building', 3, 27, 18),
(230, '3R Building', 3, 27, 19),
(231, '3R Building', 3, 27, 20),
(232, '3R Building', 3, 27, 21),
(233, '3R Building', 3, 27, 22),
(234, '3R Building', 3, 27, 23),
(235, '3R Building', 3, 28, 18),
(236, '3R Building', 3, 28, 23),
(237, '3R Building', 3, 29, 18),
(238, '3R Building', 3, 29, 23),
(239, '3R Building', 3, 30, 18),
(240, '3R Building', 3, 30, 23),
(241, '3R Building', 3, 31, 18),
(242, '3R Building', 3, 31, 23),
(243, '3R Building', 3, 32, 18),
(244, '3R Building', 3, 32, 23),
(245, '3R Building', 3, 33, 18),
(246, '3R Building', 3, 33, 23),
(247, '3R Building', 3, 34, 18),
(248, '3R Building', 3, 34, 23),
(249, '3R Building', 3, 12, 17),
(250, '3R Building', 3, 13, 17),
(251, '3R Building', 3, 14, 17),
(252, '3R Building', 3, 15, 17),
(253, '3R Building', 3, 16, 17),
(254, '3R Building', 3, 17, 17),
(255, '3R Building', 3, 18, 17),
(256, '3R Building', 3, 19, 17),
(257, '3R Building', 3, 20, 17),
(258, '3R Building', 3, 21, 17),
(259, '3R Building', 3, 22, 17),
(260, '3R Building', 3, 23, 17),
(261, '3R Building', 3, 24, 17),
(262, '3R Building', 3, 25, 17),
(263, '3R Building', 3, 26, 17),
(264, '3R Building', 3, 45, 27),
(265, '3R Building', 3, 45, 28),
(266, '3R Building', 3, 45, 29),
(267, '3R Building', 3, 45, 30),
(268, '3R Building', 3, 46, 27),
(269, '3R Building', 3, 46, 30),
(270, '3R Building', 3, 47, 27),
(271, '3R Building', 3, 47, 30),
(272, '3R Building', 3, 48, 27),
(273, '3R Building', 3, 48, 30),
(274, '3R Building', 3, 49, 27),
(275, '3R Building', 3, 49, 30),
(276, '3R Building', 3, 50, 27),
(277, '3R Building', 3, 50, 30),
(278, '3R Building', 3, 51, 27),
(279, '3R Building', 3, 51, 30),
(280, '3R Building', 3, 52, 27),
(281, '3R Building', 3, 52, 30),
(282, '3R Building', 3, 53, 27),
(283, '3R Building', 3, 53, 30),
(284, '3R Building', 3, 54, 27),
(285, '3R Building', 3, 54, 30),
(286, '3R Building', 3, 55, 27),
(287, '3R Building', 3, 55, 30),
(288, '3R Building', 3, 56, 27),
(289, '3R Building', 3, 56, 30),
(290, '3R Building', 3, 57, 27),
(291, '3R Building', 3, 57, 28),
(292, '3R Building', 3, 57, 29),
(293, '3R Building', 3, 57, 30),
(294, '3R Building', 3, 31, 24),
(295, '3R Building', 3, 31, 25),
(296, '3R Building', 3, 31, 26),
(297, '3R Building', 3, 32, 24),
(298, '3R Building', 3, 32, 26),
(299, '3R Building', 3, 33, 24),
(300, '3R Building', 3, 33, 26),
(301, '3R Building', 3, 34, 24),
(302, '3R Building', 3, 34, 26),
(303, '3R Building', 3, 35, 24),
(304, '3R Building', 3, 35, 26),
(305, '3R Building', 3, 36, 24),
(306, '3R Building', 3, 36, 26),
(307, '3R Building', 3, 37, 24),
(308, '3R Building', 3, 37, 26),
(309, '3R Building', 3, 38, 24),
(310, '3R Building', 3, 38, 26),
(311, '3R Building', 3, 39, 24),
(312, '3R Building', 3, 39, 26),
(313, '3R Building', 3, 40, 24),
(314, '3R Building', 3, 40, 26),
(315, '3R Building', 3, 41, 24),
(316, '3R Building', 3, 41, 26),
(317, '3R Building', 3, 42, 24),
(318, '3R Building', 3, 42, 26),
(319, '3R Building', 3, 43, 24),
(320, '3R Building', 3, 43, 26),
(321, '3R Building', 3, 44, 24),
(322, '3R Building', 3, 44, 25),
(323, '3R Building', 3, 44, 26),
(324, '3R Building', 3, 4, 36),
(325, '3R Building', 3, 5, 36),
(326, '3R Building', 3, 6, 36),
(327, '3R Building', 3, 7, 36),
(328, '3R Building', 3, 8, 36),
(329, '3R Building', 3, 9, 36),
(330, '3R Building', 3, 10, 36),
(331, '3R Building', 3, 11, 36),
(332, '3R Building', 3, 12, 36),
(333, '3R Building', 3, 13, 36),
(334, '3R Building', 3, 14, 36),
(335, '3R Building', 3, 15, 36),
(336, '3R Building', 3, 16, 36),
(337, '3R Building', 3, 17, 36),
(338, '3R Building', 3, 18, 36),
(339, '3R Building', 3, 19, 36),
(340, '3R Building', 3, 20, 36),
(341, '3R Building', 3, 21, 36),
(342, '3R Building', 3, 22, 36),
(343, '3R Building', 3, 23, 36),
(344, '3R Building', 3, 24, 36),
(345, '3R Building', 3, 25, 36),
(346, '3R Building', 3, 26, 36),
(347, '3R Building', 3, 27, 36),
(348, '3R Building', 3, 28, 36),
(349, '3R Building', 3, 29, 36),
(350, '3R Building', 3, 30, 36),
(351, '3R Building', 3, 31, 31),
(352, '3R Building', 3, 31, 32),
(353, '3R Building', 3, 31, 33),
(354, '3R Building', 3, 31, 34),
(355, '3R Building', 3, 31, 35),
(356, '3R Building', 3, 31, 36),
(357, '3R Building', 3, 31, 37),
(358, '3R Building', 3, 31, 38),
(359, '3R Building', 3, 31, 39),
(360, '3R Building', 3, 31, 40),
(361, '3R Building', 3, 31, 41),
(362, '3R Building', 3, 31, 42),
(363, '3R Building', 3, 31, 43),
(364, '3R Building', 3, 32, 31),
(365, '3R Building', 3, 32, 43),
(366, '3R Building', 3, 33, 31),
(367, '3R Building', 3, 33, 43),
(368, '3R Building', 3, 34, 31),
(369, '3R Building', 3, 34, 43),
(370, '3R Building', 3, 35, 31),
(371, '3R Building', 3, 35, 43),
(372, '3R Building', 3, 36, 31),
(373, '3R Building', 3, 36, 43),
(374, '3R Building', 3, 37, 31),
(375, '3R Building', 3, 37, 32),
(376, '3R Building', 3, 37, 33),
(377, '3R Building', 3, 37, 34),
(378, '3R Building', 3, 37, 35),
(379, '3R Building', 3, 37, 36),
(380, '3R Building', 3, 37, 37),
(381, '3R Building', 3, 37, 38),
(382, '3R Building', 3, 37, 39),
(383, '3R Building', 3, 37, 40),
(384, '3R Building', 3, 37, 41),
(385, '3R Building', 3, 37, 42),
(386, '3R Building', 3, 37, 43),
(387, '3R Building', 3, 4, 43),
(388, '3R Building', 3, 5, 43),
(389, '3R Building', 3, 6, 43),
(390, '3R Building', 3, 7, 43),
(391, '3R Building', 3, 8, 43),
(392, '3R Building', 3, 9, 43),
(393, '3R Building', 3, 10, 43),
(394, '3R Building', 3, 11, 43),
(395, '3R Building', 3, 12, 43),
(396, '3R Building', 3, 13, 43),
(397, '3R Building', 3, 14, 43),
(398, '3R Building', 3, 15, 43),
(399, '3R Building', 3, 16, 43),
(400, '3R Building', 3, 17, 43),
(401, '3R Building', 3, 18, 43),
(402, '3R Building', 3, 19, 43),
(403, '3R Building', 3, 20, 43),
(404, '3R Building', 3, 21, 43),
(405, '3R Building', 3, 22, 43),
(406, '3R Building', 3, 23, 43),
(407, '3R Building', 3, 24, 43),
(408, '3R Building', 3, 25, 43),
(409, '3R Building', 3, 26, 43),
(410, '3R Building', 3, 27, 43),
(411, '3R Building', 3, 28, 43),
(412, '3R Building', 3, 29, 43),
(413, '3R Building', 3, 30, 43),
(414, '3R Building', 3, 31, 43),
(415, '3R Building', 3, 32, 43),
(416, '3R Building', 3, 33, 43),
(417, '3R Building', 3, 34, 43),
(418, '3R Building', 3, 35, 43),
(419, '3R Building', 3, 36, 43);

-- --------------------------------------------------------

--
-- Table structure for table `preserveuser`
--

CREATE TABLE `preserveuser` (
  `userID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `search_history`
--

CREATE TABLE `search_history` (
  `id` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `search_term` varchar(255) NOT NULL,
  `search_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_preferences`
--

CREATE TABLE `settings_preferences` (
  `preferenceID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `lightDarkMode` enum('light','dark') NOT NULL DEFAULT 'light',
  `notifications` tinyint(1) NOT NULL DEFAULT 1,
  `language` varchar(50) NOT NULL DEFAULT 'English'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_profile`
--

CREATE TABLE `settings_profile` (
  `profileID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `profilepic` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `special_coordinates`
--

CREATE TABLE `special_coordinates` (
  `coordinateID` int(11) NOT NULL,
  `classroomID` int(11) DEFAULT NULL,
  `facilityID` int(11) DEFAULT NULL,
  `x_coordinate` int(11) NOT NULL,
  `y_coordinate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `special_coordinates`
--

INSERT INTO `special_coordinates` (`coordinateID`, `classroomID`, `facilityID`, `x_coordinate`, `y_coordinate`) VALUES
(33310, 3006, NULL, 4, 40),
(33312, 3001, NULL, 4, 44),
(33320, 3004, NULL, 15, 36),
(33321, 3010, NULL, 18, 43),
(33324, 3020, NULL, 44, 24),
(33326, 3002, NULL, 28, 36),
(33329, 3019, NULL, 58, 33),
(33330, NULL, 3233, 31, 27),
(33331, NULL, 3223, 29, 5),
(33332, NULL, NULL, 15, 17),
(33334, 3014, NULL, 43, 43),
(33335, 3024, NULL, 61, 17),
(33337, 3020, NULL, 44, 23),
(33339, 3026, NULL, 42, 10),
(33340, NULL, 3202, 65, 42),
(33341, NULL, 3201, 65, 39),
(33342, 3023, NULL, 58, 16),
(33343, 3005, NULL, 8, 36),
(33345, NULL, NULL, 6, 43),
(33346, NULL, 3211, 31, 5),
(33347, 3034, NULL, 11, 17),
(33348, 3015, NULL, 41, 43),
(33349, 3018, NULL, 61, 34),
(33351, 3011, NULL, 15, 36),
(33353, 3015, NULL, 41, 30),
(33355, 3012, NULL, 31, 43),
(33356, NULL, 3200, 65, 37),
(33358, 3020, NULL, 61, 28),
(33359, 3031, NULL, 24, 17),
(33361, 3025, NULL, 61, 12),
(33364, 3013, NULL, 28, 43),
(33366, 3028, NULL, 40, 21),
(33367, 3010, NULL, 11, 43),
(33368, 3017, NULL, 51, 43),
(33370, NULL, 3235, 13, 5),
(33372, 3016, NULL, 52, 43),
(33374, NULL, NULL, 17, 17),
(33377, 3009, NULL, 8, 36),
(33378, 3030, NULL, 24, 5),
(33381, 3003, NULL, 19, 36),
(33383, 3036, NULL, 12, 17),
(33385, 3023, NULL, 58, 17),
(33389, 3012, NULL, 24, 43),
(33390, NULL, 3203, 29, 5),
(33392, 3027, NULL, 39, 11),
(33395, NULL, NULL, 23, 17),
(33398, 3041, NULL, 59, 45),
(33399, 3022, NULL, 61, 23);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `department` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `studentID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `faculty` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `userType` enum('student','staff','admin') NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `number` varchar(20) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `lastLoginDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `salt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

CREATE TABLE `usertype` (
  `userTypeID` int(8) NOT NULL,
  `userTypeName` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`adminID`),
  ADD UNIQUE KEY `userID` (`userID`);

--
-- Indexes for table `buildings`
--
ALTER TABLE `buildings`
  ADD PRIMARY KEY (`buildingID`),
  ADD UNIQUE KEY `building_name` (`building_name`);

--
-- Indexes for table `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`classroomID`);

--
-- Indexes for table `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`facilityID`);

--
-- Indexes for table `paths`
--
ALTER TABLE `paths`
  ADD PRIMARY KEY (`pathID`);

--
-- Indexes for table `preserveuser`
--
ALTER TABLE `preserveuser`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `search_history`
--
ALTER TABLE `search_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `settings_preferences`
--
ALTER TABLE `settings_preferences`
  ADD PRIMARY KEY (`preferenceID`),
  ADD UNIQUE KEY `userID` (`userID`);

--
-- Indexes for table `settings_profile`
--
ALTER TABLE `settings_profile`
  ADD PRIMARY KEY (`profileID`),
  ADD UNIQUE KEY `userID` (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `special_coordinates`
--
ALTER TABLE `special_coordinates`
  ADD PRIMARY KEY (`coordinateID`),
  ADD KEY `classroomID` (`classroomID`),
  ADD KEY `facilityID` (`facilityID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffID`),
  ADD UNIQUE KEY `userID` (`userID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentID`),
  ADD UNIQUE KEY `userID` (`userID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `paths`
--
ALTER TABLE `paths`
  MODIFY `pathID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=420;

--
-- AUTO_INCREMENT for table `search_history`
--
ALTER TABLE `search_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings_preferences`
--
ALTER TABLE `settings_preferences`
  MODIFY `preferenceID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings_profile`
--
ALTER TABLE `settings_profile`
  MODIFY `profileID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `admins_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `preserveuser`
--
ALTER TABLE `preserveuser`
  ADD CONSTRAINT `preserveuser_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `admins` (`adminID`);

--
-- Constraints for table `search_history`
--
ALTER TABLE `search_history`
  ADD CONSTRAINT `search_history_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `settings_preferences`
--
ALTER TABLE `settings_preferences`
  ADD CONSTRAINT `settings_preferences_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `settings_profile`
--
ALTER TABLE `settings_profile`
  ADD CONSTRAINT `settings_profile_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `special_coordinates`
--
ALTER TABLE `special_coordinates`
  ADD CONSTRAINT `special_coordinates_ibfk_1` FOREIGN KEY (`classroomID`) REFERENCES `classrooms` (`classroomID`) ON DELETE CASCADE,
  ADD CONSTRAINT `special_coordinates_ibfk_2` FOREIGN KEY (`facilityID`) REFERENCES `facilities` (`facilityID`) ON DELETE CASCADE;

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
