-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2025 at 05:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `campus_navigation`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `adminID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `permissions` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `buildings`
--

CREATE TABLE `buildings` (
  `buildingID` int(11) NOT NULL,
  `building_name` varchar(100) NOT NULL,
  `total_floors` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `classrooms`
--

CREATE TABLE `classrooms` (
  `classroomID` int(11) NOT NULL,
  `room_number` varchar(50) NOT NULL,
  `building_name` varchar(100) NOT NULL,
  `floor_number` int(11) NOT NULL,
  `x_min` int(11) NOT NULL,
  `y_min` int(11) NOT NULL,
  `x_max` int(11) NOT NULL,
  `y_max` int(11) NOT NULL,
  `room_type` enum('lecture room','lab','workshop/studio') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classrooms`
--

INSERT INTO `classrooms` (`classroomID`, `room_number`, `building_name`, `floor_number`, `x_min`, `y_min`, `x_max`, `y_max`, `room_type`) VALUES
(2008, '2R008 PhD Room', '2R Building', 2, 64, 45, 68, 49, 'lecture room'),
(2011, '2R011 Lecture Hall', '2R Building', 2, 55, 32, 68, 37, 'lecture room'),
(2012, '2R012 Lecture Hall', '2R Building', 2, 55, 27, 68, 31, 'lecture room'),
(2013, '2R013 Lecture Hall', '2R Building', 2, 55, 22, 68, 26, 'lecture room'),
(2014, '2R014 Lecture Hall', '2R Building', 2, 55, 12, 68, 21, 'lecture room'),
(2016, '2R016 Lecture Hall', '2R Building', 2, 55, 0, 68, 9, 'lecture room'),
(2028, '2R028 Teaching & Learning Room', '2R Building', 2, 30, 7, 48, 10, 'lecture room'),
(2029, '2R029 Teaching & Learning Room', '2R Building', 2, 31, 7, 38, 10, 'lecture room'),
(3002, '3R002 Lecture Room', '3R Building', 3, 25, 31, 30, 35, 'lecture room'),
(3003, '3R003 Lecture Room', '3R Building', 3, 18, 31, 24, 35, 'lecture room'),
(3004, '3R004 Lecture Room', '3R Building', 3, 12, 31, 17, 35, 'lecture room'),
(3005, '3R005 Lecture Room', '3R Building', 3, 6, 28, 11, 35, 'lecture room'),
(3006, '3R006 Lecture Room', '3R Building', 3, 0, 36, 3, 41, 'lecture room'),
(3008, '3R008 Lecture Room', '3R Building', 3, 4, 44, 7, 47, 'lecture room'),
(3009, '3R009 Lecture Room', '3R Building', 3, 5, 37, 11, 42, 'lecture room'),
(3010, '3R010 Mechanical Workshop', '3R Building', 3, 8, 44, 20, 49, 'workshop/studio'),
(3011, '3R011 Lecture Room', '3R Building', 3, 12, 37, 17, 42, 'lecture room'),
(3012, '3R012 Green Engineering Laboratory', '3R Building', 3, 21, 44, 33, 49, 'lab'),
(3013, '3R013 Materials & Structures Laboratory', '3R Building', 3, 18, 37, 30, 42, 'lab'),
(3014, '3R014 Aerospace Laboratory', '3R Building', 3, 34, 44, 46, 49, 'lab'),
(3015, '3R015 Design Studio', '3R Building', 3, 38, 31, 44, 42, 'workshop/studio'),
(3016, '3R016 Thermodynamics Laboratory', '3R Building', 3, 47, 44, 57, 49, 'lab'),
(3017, '3R017 Lecture Room', '3R Building', 3, 45, 37, 57, 42, 'lecture room'),
(3018, '3R018 Lecture Room', '3R Building', 3, 62, 31, 68, 35, 'lecture room'),
(3019, '3R019 Lecture Room', '3R Building', 3, 45, 31, 57, 36, 'lecture room'),
(3020, '3R020 Lecture Room', '3R Building', 3, 62, 26, 68, 30, 'lecture room'),
(3021, '3R021 Lecture Room', '3R Building', 3, 45, 21, 57, 26, 'lecture room'),
(3022, '3R022 Lecture Room', '3R Building', 3, 62, 20, 68, 25, 'lecture room'),
(3023, '3R023 Computer Science Laboratory', '3R Building', 3, 45, 12, 57, 20, 'lab'),
(3024, '3R024 Lecture Room', '3R Building', 3, 62, 15, 68, 19, 'lecture room'),
(3025, '3R025 Lecture Room', '3R Building', 3, 62, 10, 68, 14, 'lecture room'),
(3026, '3R026 Lecture Hall', '3R Building', 3, 35, 0, 48, 9, 'lecture room'),
(3027, '3R027 Computer Science Laboratory', '3R Building', 3, 35, 12, 44, 16, 'lab'),
(3028, '3R028 Computer Science Laboratory', '3R Building', 3, 35, 17, 44, 20, 'lab'),
(3030, '3R030 Lecture Room', '3R Building', 3, 21, 6, 27, 12, 'lecture room'),
(3031, '3R031 Lecture Room', '3R Building', 3, 21, 13, 27, 16, 'lecture room'),
(3032, '3R032 Engineering Foundation Laboratory 1', '3R Building', 3, 12, 18, 26, 23, 'lab'),
(3033, '3R033 Engineering Foundation Laboratory 2', '3R Building', 3, 13, 7, 20, 16, 'lab'),
(3034, '3R034 Engineering Foundation Laboratory 3', '3R Building', 3, 5, 7, 12, 16, 'lab');

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE `facilities` (
  `facilityID` int(11) NOT NULL,
  `facility_number` varchar(50) NOT NULL,
  `type` enum('toilet','lift','emergency_exit','surau') NOT NULL,
  `building_name` varchar(100) NOT NULL,
  `floor_number` int(11) NOT NULL,
  `x_min` int(11) NOT NULL,
  `x_max` int(11) NOT NULL,
  `y_min` int(11) NOT NULL,
  `y_max` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`facilityID`, `facility_number`, `type`, `building_name`, `floor_number`, `x_min`, `x_max`, `y_min`, `y_max`) VALUES
(2200, '2R002 Library', '', '2R Building', 2, 8, 34, 32, 49),
(2201, '2R002 Library', '', '2R Building', 2, 0, 7, 38, 47),
(2202, '2R002 Library', '', '2R Building', 2, 35, 46, 38, 49),
(2203, '2R003 Student Association', '', '2R Building', 2, 35, 41, 32, 37),
(2204, '2R005 Merchandise', '', '2R Building', 2, 42, 48, 32, 35),
(2205, '2R004 Digital Library', '', '2R Building', 2, 42, 48, 36, 49),
(2206, '2R006 Janitor', '', '2R Building', 2, 49, 51, 45, 49),
(2207, '2R007 Music Room', '', '2R Building', 2, 52, 62, 45, 49),
(2208, '2R009 Female Surau', 'surau', '2R Building', 2, 58, 64, 38, 41),
(2209, '2R010 Pantry', '', '2R Building', 2, 55, 57, 38, 41),
(2210, '2R015 Refreshments Area', '', '2R Building', 2, 59, 68, 10, 11),
(2211, '2R017 IT Storage', '', '2R Building', 2, 49, 54, 0, 4),
(2212, '2R018 Server Room', '', '2R Building', 2, 39, 48, 0, 4),
(2213, '2R019 Marketing Office', '', '2R Building', 2, 6, 12, 0, 2),
(2214, '2R019 Marketing Office', '', '2R Building', 2, 6, 15, 3, 11),
(2215, '2R020 Storage', '', '2R Building', 2, 13, 15, 0, 2),
(2216, '2R021 Front Desk', '', '2R Building', 2, 24, 26, 17, 21),
(2217, '2R022 Service Office', '', '2R Building', 2, 38, 41, 11, 18),
(2218, '2R023 HoD', '', '2R Building', 2, 38, 41, 19, 21),
(2219, '2R024 Strong Plan', '', '2R Building', 2, 42, 48, 16, 21),
(2220, '2R025 Student Records Room', '', '2R Building', 2, 42, 48, 14, 15),
(2221, '2R026 SickBay', '', '2R Building', 2, 42, 44, 12, 13),
(2222, '2R030 IT & Facilities Office', '', '2R Building', 2, 24, 25, 7, 8),
(2223, '2R031 Security Office', '', '2R Building', 2, 24, 25, 9, 10),
(2224, '2R032 International Student Office', '', '2R Building', 2, 24, 30, 11, 13),
(2225, '2R033 Quality Assurance', '', '2R Building', 2, 24, 30, 14, 16),
(2226, '2R Right Female Toilet', 'toilet', '2R Building', 2, 66, 68, 41, 42),
(2227, '2R Right Male Toilet', 'toilet', '2R Building', 2, 66, 68, 38, 39),
(2228, '2R Emergency Exit A', '', '2R Building', 2, 36, 38, 0, 4),
(2229, '2R Lift Lobby', '', '2R Building', 2, 20, 35, 0, 4),
(2230, '2R Toilets Bottom Left', 'toilet', '2R Building', 2, 16, 19, 0, 4),
(2231, '2R Staircase', '', '2R Building', 2, 29, 41, 24, 30),
(2232, '2R001 Foyer', '', '2R Building', 2, 11, 18, 20, 29),
(2233, '2R001 Foyer', '', '2R Building', 2, 19, 24, 24, 29),
(2234, '2R001 Foyer', '', '2R Building', 2, 6, 15, 12, 15),
(3200, '3R OKU Toilet', 'toilet', '3R Building', 3, 66, 68, 36, 37),
(3201, '3R Right Female Toilet', 'toilet', '3R Building', 3, 66, 68, 38, 40),
(3202, '3R Right Male Toilet', 'toilet', '3R Building', 3, 66, 68, 41, 43),
(3203, '3R Toilets Bottom Left', 'toilet', '3R Building', 3, 13, 16, 0, 4),
(3204, '3R Emergency Exit B', 'emergency_exit', '3R Building', 3, 31, 34, 0, 4),
(3205, '3R Lift Lobby', 'lift', '3R Building', 3, 17, 30, 0, 4),
(3206, '3R Staircase', 'emergency_exit', '3R Building', 3, 26, 30, 24, 30),
(3207, '3R035 Male Surau', 'surau', '3R Building', 3, 5, 12, 0, 6),
(3208, '3R VOID', '', '3R Building', 3, 12, 25, 24, 30),
(3209, '3R Entrance Lobby', '', '3R Building', 3, 0, 3, 42, 47),
(3210, '3R036 Lobby', '', '3R Building', 3, 5, 11, 17, 27),
(3211, '3R041 Lobby', '', '3R Building', 3, 58, 68, 46, 49),
(3217, '3R041 Lobby', '', '3R Building', 3, 61, 68, 44, 45);

-- --------------------------------------------------------

--
-- Table structure for table `paths`
--

CREATE TABLE `paths` (
  `pathID` int(11) NOT NULL,
  `building_name` varchar(100) NOT NULL,
  `floor_number` int(11) NOT NULL,
  `x_coordinate` int(11) NOT NULL,
  `y_coordinate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paths`
--

INSERT INTO `paths` (`pathID`, `building_name`, `floor_number`, `x_coordinate`, `y_coordinate`) VALUES
(1, '3R Building', 3, 4, 43),
(2, '3R Building', 3, 5, 43),
(3, '3R Building', 3, 6, 43),
(4, '3R Building', 3, 7, 43),
(5, '3R Building', 3, 8, 43),
(6, '3R Building', 3, 9, 43),
(7, '3R Building', 3, 10, 43),
(8, '3R Building', 3, 11, 43),
(9, '3R Building', 3, 12, 43),
(10, '3R Building', 3, 13, 43),
(11, '3R Building', 3, 14, 43),
(12, '3R Building', 3, 15, 43),
(13, '3R Building', 3, 16, 43),
(14, '3R Building', 3, 17, 43),
(15, '3R Building', 3, 18, 43),
(16, '3R Building', 3, 19, 43),
(17, '3R Building', 3, 20, 43),
(18, '3R Building', 3, 21, 43),
(19, '3R Building', 3, 22, 43),
(20, '3R Building', 3, 23, 43),
(21, '3R Building', 3, 24, 43),
(22, '3R Building', 3, 25, 43),
(23, '3R Building', 3, 26, 43),
(24, '3R Building', 3, 27, 43),
(25, '3R Building', 3, 28, 43),
(26, '3R Building', 3, 29, 43),
(27, '3R Building', 3, 30, 43),
(28, '3R Building', 3, 31, 43),
(29, '3R Building', 3, 32, 43),
(30, '3R Building', 3, 33, 43),
(31, '3R Building', 3, 34, 43),
(32, '3R Building', 3, 35, 43),
(33, '3R Building', 3, 36, 43),
(34, '3R Building', 3, 37, 43),
(35, '3R Building', 3, 38, 43),
(36, '3R Building', 3, 39, 43),
(37, '3R Building', 3, 40, 43),
(38, '3R Building', 3, 41, 43),
(39, '3R Building', 3, 42, 43),
(40, '3R Building', 3, 43, 43),
(41, '3R Building', 3, 44, 43),
(42, '3R Building', 3, 45, 43),
(43, '3R Building', 3, 46, 43),
(44, '3R Building', 3, 47, 43),
(45, '3R Building', 3, 48, 43),
(46, '3R Building', 3, 49, 43),
(47, '3R Building', 3, 50, 43),
(48, '3R Building', 3, 51, 43),
(49, '3R Building', 3, 52, 43),
(50, '3R Building', 3, 53, 43),
(51, '3R Building', 3, 54, 43),
(52, '3R Building', 3, 55, 43),
(53, '3R Building', 3, 56, 43),
(54, '3R Building', 3, 57, 43),
(55, '3R Building', 3, 58, 43),
(56, '3R Building', 3, 59, 43),
(57, '3R Building', 3, 60, 43),
(58, '3R Building', 3, 61, 43),
(59, '3R Building', 3, 62, 43),
(60, '3R Building', 3, 63, 43),
(61, '3R Building', 3, 64, 43),
(62, '3R Building', 3, 65, 43),
(63, '3R Building', 3, 58, 44),
(64, '3R Building', 3, 59, 44),
(65, '3R Building', 3, 60, 44),
(66, '3R Building', 3, 58, 45),
(67, '3R Building', 3, 59, 45),
(68, '3R Building', 3, 60, 45),
(69, '3R Building', 3, 58, 36),
(70, '3R Building', 3, 59, 36),
(71, '3R Building', 3, 60, 36),
(72, '3R Building', 3, 61, 36),
(73, '3R Building', 3, 62, 36),
(74, '3R Building', 3, 63, 36),
(75, '3R Building', 3, 64, 36),
(76, '3R Building', 3, 65, 36),
(77, '3R Building', 3, 58, 37),
(78, '3R Building', 3, 59, 37),
(79, '3R Building', 3, 60, 37),
(80, '3R Building', 3, 61, 37),
(81, '3R Building', 3, 62, 37),
(82, '3R Building', 3, 63, 37),
(83, '3R Building', 3, 64, 37),
(84, '3R Building', 3, 65, 37),
(85, '3R Building', 3, 58, 38),
(86, '3R Building', 3, 59, 38),
(87, '3R Building', 3, 60, 38),
(88, '3R Building', 3, 61, 38),
(89, '3R Building', 3, 62, 38),
(90, '3R Building', 3, 63, 38),
(91, '3R Building', 3, 64, 38),
(92, '3R Building', 3, 65, 38),
(93, '3R Building', 3, 58, 39),
(94, '3R Building', 3, 59, 39),
(95, '3R Building', 3, 60, 39),
(96, '3R Building', 3, 61, 39),
(97, '3R Building', 3, 62, 39),
(98, '3R Building', 3, 63, 39),
(99, '3R Building', 3, 64, 39),
(100, '3R Building', 3, 65, 39),
(101, '3R Building', 3, 58, 40),
(102, '3R Building', 3, 59, 40),
(103, '3R Building', 3, 60, 40),
(104, '3R Building', 3, 61, 40),
(105, '3R Building', 3, 62, 40),
(106, '3R Building', 3, 63, 40),
(107, '3R Building', 3, 64, 40),
(108, '3R Building', 3, 65, 40),
(109, '3R Building', 3, 58, 41),
(110, '3R Building', 3, 59, 41),
(111, '3R Building', 3, 60, 41),
(112, '3R Building', 3, 61, 41),
(113, '3R Building', 3, 62, 41),
(114, '3R Building', 3, 63, 41),
(115, '3R Building', 3, 64, 41),
(116, '3R Building', 3, 65, 41),
(117, '3R Building', 3, 58, 42),
(118, '3R Building', 3, 59, 42),
(119, '3R Building', 3, 60, 42),
(120, '3R Building', 3, 61, 42),
(121, '3R Building', 3, 62, 42),
(122, '3R Building', 3, 63, 42),
(123, '3R Building', 3, 64, 42),
(124, '3R Building', 3, 65, 42),
(125, '3R Building', 3, 58, 10),
(126, '3R Building', 3, 58, 11),
(127, '3R Building', 3, 58, 12),
(128, '3R Building', 3, 58, 13),
(129, '3R Building', 3, 58, 14),
(130, '3R Building', 3, 58, 15),
(131, '3R Building', 3, 58, 16),
(132, '3R Building', 3, 58, 17),
(133, '3R Building', 3, 58, 18),
(134, '3R Building', 3, 58, 19),
(135, '3R Building', 3, 58, 20),
(136, '3R Building', 3, 58, 21),
(137, '3R Building', 3, 58, 22),
(138, '3R Building', 3, 58, 23),
(139, '3R Building', 3, 58, 24),
(140, '3R Building', 3, 58, 25),
(141, '3R Building', 3, 58, 26),
(142, '3R Building', 3, 58, 27),
(143, '3R Building', 3, 58, 28),
(144, '3R Building', 3, 58, 29),
(145, '3R Building', 3, 58, 30),
(146, '3R Building', 3, 58, 31),
(147, '3R Building', 3, 58, 32),
(148, '3R Building', 3, 58, 33),
(149, '3R Building', 3, 58, 34),
(150, '3R Building', 3, 58, 35),
(151, '3R Building', 3, 59, 10),
(152, '3R Building', 3, 59, 35),
(153, '3R Building', 3, 60, 10),
(154, '3R Building', 3, 60, 35),
(155, '3R Building', 3, 61, 10),
(156, '3R Building', 3, 61, 35),
(157, '3R Building', 3, 28, 10),
(158, '3R Building', 3, 29, 10),
(159, '3R Building', 3, 30, 10),
(160, '3R Building', 3, 31, 10),
(161, '3R Building', 3, 32, 10),
(162, '3R Building', 3, 33, 10),
(163, '3R Building', 3, 34, 10),
(164, '3R Building', 3, 35, 10),
(165, '3R Building', 3, 36, 10),
(166, '3R Building', 3, 37, 10),
(167, '3R Building', 3, 38, 10),
(168, '3R Building', 3, 39, 10),
(169, '3R Building', 3, 40, 10),
(170, '3R Building', 3, 41, 10),
(171, '3R Building', 3, 42, 10),
(172, '3R Building', 3, 43, 10),
(173, '3R Building', 3, 44, 10),
(174, '3R Building', 3, 45, 10),
(175, '3R Building', 3, 46, 10),
(176, '3R Building', 3, 47, 10),
(177, '3R Building', 3, 48, 10),
(178, '3R Building', 3, 49, 10),
(179, '3R Building', 3, 50, 10),
(180, '3R Building', 3, 51, 10),
(181, '3R Building', 3, 52, 10),
(182, '3R Building', 3, 53, 10),
(183, '3R Building', 3, 54, 10),
(184, '3R Building', 3, 55, 10),
(185, '3R Building', 3, 56, 10),
(186, '3R Building', 3, 57, 10),
(187, '3R Building', 3, 28, 11),
(188, '3R Building', 3, 57, 11),
(189, '3R Building', 3, 28, 5),
(190, '3R Building', 3, 28, 6),
(191, '3R Building', 3, 28, 7),
(192, '3R Building', 3, 28, 8),
(193, '3R Building', 3, 28, 9),
(194, '3R Building', 3, 28, 10),
(195, '3R Building', 3, 28, 11),
(196, '3R Building', 3, 28, 12),
(197, '3R Building', 3, 28, 13),
(198, '3R Building', 3, 28, 14),
(199, '3R Building', 3, 28, 15),
(200, '3R Building', 3, 28, 16),
(201, '3R Building', 3, 28, 17),
(202, '3R Building', 3, 29, 5),
(203, '3R Building', 3, 29, 17),
(204, '3R Building', 3, 30, 5),
(205, '3R Building', 3, 30, 17),
(206, '3R Building', 3, 31, 5),
(207, '3R Building', 3, 31, 17),
(208, '3R Building', 3, 32, 5),
(209, '3R Building', 3, 32, 17),
(210, '3R Building', 3, 33, 5),
(211, '3R Building', 3, 33, 17),
(212, '3R Building', 3, 34, 5),
(213, '3R Building', 3, 34, 17),
(214, '3R Building', 3, 13, 5),
(215, '3R Building', 3, 14, 5),
(216, '3R Building', 3, 15, 5),
(217, '3R Building', 3, 16, 5),
(218, '3R Building', 3, 17, 5),
(219, '3R Building', 3, 18, 5),
(220, '3R Building', 3, 19, 5),
(221, '3R Building', 3, 20, 5),
(222, '3R Building', 3, 21, 5),
(223, '3R Building', 3, 22, 5),
(224, '3R Building', 3, 23, 5),
(225, '3R Building', 3, 24, 5),
(226, '3R Building', 3, 25, 5),
(227, '3R Building', 3, 26, 5),
(228, '3R Building', 3, 27, 5),
(229, '3R Building', 3, 27, 18),
(230, '3R Building', 3, 27, 19),
(231, '3R Building', 3, 27, 20),
(232, '3R Building', 3, 27, 21),
(233, '3R Building', 3, 27, 22),
(234, '3R Building', 3, 27, 23),
(235, '3R Building', 3, 28, 18),
(236, '3R Building', 3, 28, 23),
(237, '3R Building', 3, 29, 18),
(238, '3R Building', 3, 29, 23),
(239, '3R Building', 3, 30, 18),
(240, '3R Building', 3, 30, 23),
(241, '3R Building', 3, 31, 18),
(242, '3R Building', 3, 31, 23),
(243, '3R Building', 3, 32, 18),
(244, '3R Building', 3, 32, 23),
(245, '3R Building', 3, 33, 18),
(246, '3R Building', 3, 33, 23),
(247, '3R Building', 3, 34, 18),
(248, '3R Building', 3, 34, 23),
(249, '3R Building', 3, 12, 17),
(250, '3R Building', 3, 13, 17),
(251, '3R Building', 3, 14, 17),
(252, '3R Building', 3, 15, 17),
(253, '3R Building', 3, 16, 17),
(254, '3R Building', 3, 17, 17),
(255, '3R Building', 3, 18, 17),
(256, '3R Building', 3, 19, 17),
(257, '3R Building', 3, 20, 17),
(258, '3R Building', 3, 21, 17),
(259, '3R Building', 3, 22, 17),
(260, '3R Building', 3, 23, 17),
(261, '3R Building', 3, 24, 17),
(262, '3R Building', 3, 25, 17),
(263, '3R Building', 3, 26, 17),
(264, '3R Building', 3, 45, 27),
(265, '3R Building', 3, 45, 28),
(266, '3R Building', 3, 45, 29),
(267, '3R Building', 3, 45, 30),
(268, '3R Building', 3, 46, 27),
(269, '3R Building', 3, 46, 30),
(270, '3R Building', 3, 47, 27),
(271, '3R Building', 3, 47, 30),
(272, '3R Building', 3, 48, 27),
(273, '3R Building', 3, 48, 30),
(274, '3R Building', 3, 49, 27),
(275, '3R Building', 3, 49, 30),
(276, '3R Building', 3, 50, 27),
(277, '3R Building', 3, 50, 30),
(278, '3R Building', 3, 51, 27),
(279, '3R Building', 3, 51, 30),
(280, '3R Building', 3, 52, 27),
(281, '3R Building', 3, 52, 30),
(282, '3R Building', 3, 53, 27),
(283, '3R Building', 3, 53, 30),
(284, '3R Building', 3, 54, 27),
(285, '3R Building', 3, 54, 30),
(286, '3R Building', 3, 55, 27),
(287, '3R Building', 3, 55, 30),
(288, '3R Building', 3, 56, 27),
(289, '3R Building', 3, 56, 30),
(290, '3R Building', 3, 57, 27),
(291, '3R Building', 3, 57, 28),
(292, '3R Building', 3, 57, 29),
(293, '3R Building', 3, 57, 30),
(294, '3R Building', 3, 31, 24),
(295, '3R Building', 3, 31, 25),
(296, '3R Building', 3, 31, 26),
(297, '3R Building', 3, 32, 24),
(298, '3R Building', 3, 32, 26),
(299, '3R Building', 3, 33, 24),
(300, '3R Building', 3, 33, 26),
(301, '3R Building', 3, 34, 24),
(302, '3R Building', 3, 34, 26),
(303, '3R Building', 3, 35, 24),
(304, '3R Building', 3, 35, 26),
(305, '3R Building', 3, 36, 24),
(306, '3R Building', 3, 36, 26),
(307, '3R Building', 3, 37, 24),
(308, '3R Building', 3, 37, 26),
(309, '3R Building', 3, 38, 24),
(310, '3R Building', 3, 38, 26),
(311, '3R Building', 3, 39, 24),
(312, '3R Building', 3, 39, 26),
(313, '3R Building', 3, 40, 24),
(314, '3R Building', 3, 40, 26),
(315, '3R Building', 3, 41, 24),
(316, '3R Building', 3, 41, 26),
(317, '3R Building', 3, 42, 24),
(318, '3R Building', 3, 42, 26),
(319, '3R Building', 3, 43, 24),
(320, '3R Building', 3, 43, 26),
(321, '3R Building', 3, 44, 24),
(322, '3R Building', 3, 44, 25),
(323, '3R Building', 3, 44, 26),
(324, '3R Building', 3, 4, 36),
(325, '3R Building', 3, 5, 36),
(326, '3R Building', 3, 6, 36),
(327, '3R Building', 3, 7, 36),
(328, '3R Building', 3, 8, 36),
(329, '3R Building', 3, 9, 36),
(330, '3R Building', 3, 10, 36),
(331, '3R Building', 3, 11, 36),
(332, '3R Building', 3, 12, 36),
(333, '3R Building', 3, 13, 36),
(334, '3R Building', 3, 14, 36),
(335, '3R Building', 3, 15, 36),
(336, '3R Building', 3, 16, 36),
(337, '3R Building', 3, 17, 36),
(338, '3R Building', 3, 18, 36),
(339, '3R Building', 3, 19, 36),
(340, '3R Building', 3, 20, 36),
(341, '3R Building', 3, 21, 36),
(342, '3R Building', 3, 22, 36),
(343, '3R Building', 3, 23, 36),
(344, '3R Building', 3, 24, 36),
(345, '3R Building', 3, 25, 36),
(346, '3R Building', 3, 26, 36),
(347, '3R Building', 3, 27, 36),
(348, '3R Building', 3, 28, 36),
(349, '3R Building', 3, 29, 36),
(350, '3R Building', 3, 30, 36),
(351, '3R Building', 3, 31, 31),
(352, '3R Building', 3, 31, 32),
(353, '3R Building', 3, 31, 33),
(354, '3R Building', 3, 31, 34),
(355, '3R Building', 3, 31, 35),
(356, '3R Building', 3, 31, 36),
(357, '3R Building', 3, 31, 37),
(358, '3R Building', 3, 31, 38),
(359, '3R Building', 3, 31, 39),
(360, '3R Building', 3, 31, 40),
(361, '3R Building', 3, 31, 41),
(362, '3R Building', 3, 31, 42),
(363, '3R Building', 3, 31, 43),
(364, '3R Building', 3, 32, 31),
(365, '3R Building', 3, 32, 43),
(366, '3R Building', 3, 33, 31),
(367, '3R Building', 3, 33, 43),
(368, '3R Building', 3, 34, 31),
(369, '3R Building', 3, 34, 43),
(370, '3R Building', 3, 35, 31),
(371, '3R Building', 3, 35, 43),
(372, '3R Building', 3, 36, 31),
(373, '3R Building', 3, 36, 43),
(374, '3R Building', 3, 37, 31),
(375, '3R Building', 3, 37, 32),
(376, '3R Building', 3, 37, 33),
(377, '3R Building', 3, 37, 34),
(378, '3R Building', 3, 37, 35),
(379, '3R Building', 3, 37, 36),
(380, '3R Building', 3, 37, 37),
(381, '3R Building', 3, 37, 38),
(382, '3R Building', 3, 37, 39),
(383, '3R Building', 3, 37, 40),
(384, '3R Building', 3, 37, 41),
(385, '3R Building', 3, 37, 42),
(386, '3R Building', 3, 37, 43),
(387, '3R Building', 3, 4, 43),
(388, '3R Building', 3, 5, 43),
(389, '3R Building', 3, 6, 43),
(390, '3R Building', 3, 7, 43),
(391, '3R Building', 3, 8, 43),
(392, '3R Building', 3, 9, 43),
(393, '3R Building', 3, 10, 43),
(394, '3R Building', 3, 11, 43),
(395, '3R Building', 3, 12, 43),
(396, '3R Building', 3, 13, 43),
(397, '3R Building', 3, 14, 43),
(398, '3R Building', 3, 15, 43),
(399, '3R Building', 3, 16, 43),
(400, '3R Building', 3, 17, 43),
(401, '3R Building', 3, 18, 43),
(402, '3R Building', 3, 19, 43),
(403, '3R Building', 3, 20, 43),
(404, '3R Building', 3, 21, 43),
(405, '3R Building', 3, 22, 43),
(406, '3R Building', 3, 23, 43),
(407, '3R Building', 3, 24, 43),
(408, '3R Building', 3, 25, 43),
(409, '3R Building', 3, 26, 43),
(410, '3R Building', 3, 27, 43),
(411, '3R Building', 3, 28, 43),
(412, '3R Building', 3, 29, 43),
(413, '3R Building', 3, 30, 43),
(414, '3R Building', 3, 31, 43),
(415, '3R Building', 3, 32, 43),
(416, '3R Building', 3, 33, 43),
(417, '3R Building', 3, 34, 43),
(418, '3R Building', 3, 35, 43),
(419, '3R Building', 3, 36, 43),
(420, '2R Building', 2, 6, 31),
(421, '2R Building', 2, 7, 31),
(422, '2R Building', 2, 8, 31),
(423, '2R Building', 2, 9, 31),
(424, '2R Building', 2, 10, 31),
(425, '2R Building', 2, 11, 31),
(426, '2R Building', 2, 12, 31),
(427, '2R Building', 2, 13, 31),
(428, '2R Building', 2, 14, 31),
(429, '2R Building', 2, 15, 31),
(430, '2R Building', 2, 16, 31),
(431, '2R Building', 2, 17, 31),
(432, '2R Building', 2, 18, 31),
(433, '2R Building', 2, 19, 31),
(434, '2R Building', 2, 20, 31),
(435, '2R Building', 2, 21, 31),
(436, '2R Building', 2, 22, 31),
(437, '2R Building', 2, 23, 31),
(438, '2R Building', 2, 24, 31),
(439, '2R Building', 2, 25, 31),
(440, '2R Building', 2, 26, 31),
(441, '2R Building', 2, 27, 31),
(442, '2R Building', 2, 28, 31),
(443, '2R Building', 2, 29, 31),
(444, '2R Building', 2, 30, 31),
(445, '2R Building', 2, 31, 31),
(446, '2R Building', 2, 32, 31),
(447, '2R Building', 2, 33, 31),
(448, '2R Building', 2, 34, 31),
(449, '2R Building', 2, 35, 31),
(450, '2R Building', 2, 36, 31),
(451, '2R Building', 2, 37, 31),
(452, '2R Building', 2, 38, 31),
(453, '2R Building', 2, 39, 31),
(454, '2R Building', 2, 40, 31),
(455, '2R Building', 2, 41, 31),
(456, '2R Building', 2, 42, 31),
(457, '2R Building', 2, 43, 31),
(458, '2R Building', 2, 44, 31),
(459, '2R Building', 2, 45, 31),
(460, '2R Building', 2, 46, 31),
(461, '2R Building', 2, 47, 31),
(462, '2R Building', 2, 48, 31),
(463, '2R Building', 2, 49, 5),
(464, '2R Building', 2, 49, 44),
(465, '2R Building', 2, 50, 5),
(466, '2R Building', 2, 50, 44),
(467, '2R Building', 2, 51, 5),
(468, '2R Building', 2, 51, 44),
(469, '2R Building', 2, 52, 5),
(470, '2R Building', 2, 52, 44),
(471, '2R Building', 2, 53, 5),
(472, '2R Building', 2, 53, 44),
(473, '2R Building', 2, 54, 5),
(474, '2R Building', 2, 54, 44),
(475, '2R Building', 2, 55, 42),
(476, '2R Building', 2, 55, 44),
(477, '2R Building', 2, 56, 42),
(478, '2R Building', 2, 56, 44),
(479, '2R Building', 2, 57, 42),
(480, '2R Building', 2, 57, 44),
(481, '2R Building', 2, 58, 42),
(482, '2R Building', 2, 58, 44),
(483, '2R Building', 2, 59, 42),
(484, '2R Building', 2, 59, 44),
(485, '2R Building', 2, 60, 42),
(486, '2R Building', 2, 60, 44),
(487, '2R Building', 2, 61, 42),
(488, '2R Building', 2, 61, 44),
(489, '2R Building', 2, 62, 42),
(490, '2R Building', 2, 62, 44),
(491, '2R Building', 2, 63, 42),
(492, '2R Building', 2, 63, 44),
(493, '2R Building', 2, 64, 42),
(494, '2R Building', 2, 64, 44),
(495, '2R Building', 2, 52, 45),
(496, '2R Building', 2, 52, 46),
(497, '2R Building', 2, 52, 47),
(498, '2R Building', 2, 52, 48),
(499, '2R Building', 2, 52, 49),
(500, '2R Building', 2, 65, 38),
(501, '2R Building', 2, 65, 39),
(502, '2R Building', 2, 65, 40),
(503, '2R Building', 2, 65, 41),
(504, '2R Building', 2, 65, 42),
(505, '2R Building', 2, 65, 43),
(506, '2R Building', 2, 65, 44),
(507, '2R Building', 2, 66, 43),
(508, '2R Building', 2, 66, 44),
(509, '2R Building', 2, 67, 43),
(510, '2R Building', 2, 67, 44),
(511, '2R Building', 2, 68, 43),
(512, '2R Building', 2, 68, 44),
(513, '2R Building', 2, 55, 10),
(514, '2R Building', 2, 55, 11),
(515, '2R Building', 2, 56, 10),
(516, '2R Building', 2, 56, 11),
(517, '2R Building', 2, 57, 10),
(518, '2R Building', 2, 57, 11),
(519, '2R Building', 2, 58, 10),
(520, '2R Building', 2, 58, 11),
(521, '2R Building', 2, 16, 5),
(522, '2R Building', 2, 16, 6),
(523, '2R Building', 2, 17, 5),
(524, '2R Building', 2, 17, 6),
(525, '2R Building', 2, 18, 5),
(526, '2R Building', 2, 18, 6),
(527, '2R Building', 2, 19, 5),
(528, '2R Building', 2, 19, 6),
(529, '2R Building', 2, 20, 5),
(530, '2R Building', 2, 20, 6),
(531, '2R Building', 2, 21, 5),
(532, '2R Building', 2, 21, 6),
(533, '2R Building', 2, 22, 5),
(534, '2R Building', 2, 22, 6),
(535, '2R Building', 2, 23, 5),
(536, '2R Building', 2, 23, 6),
(537, '2R Building', 2, 24, 5),
(538, '2R Building', 2, 24, 6),
(539, '2R Building', 2, 25, 5),
(540, '2R Building', 2, 25, 6),
(541, '2R Building', 2, 26, 5),
(542, '2R Building', 2, 26, 6),
(543, '2R Building', 2, 27, 5),
(544, '2R Building', 2, 27, 6),
(545, '2R Building', 2, 28, 5),
(546, '2R Building', 2, 28, 6),
(547, '2R Building', 2, 29, 5),
(548, '2R Building', 2, 29, 6),
(549, '2R Building', 2, 30, 5),
(550, '2R Building', 2, 30, 6),
(551, '2R Building', 2, 31, 5),
(552, '2R Building', 2, 31, 6),
(553, '2R Building', 2, 32, 5),
(554, '2R Building', 2, 32, 6),
(555, '2R Building', 2, 33, 5),
(556, '2R Building', 2, 33, 6),
(557, '2R Building', 2, 34, 5),
(558, '2R Building', 2, 34, 6),
(559, '2R Building', 2, 35, 5),
(560, '2R Building', 2, 35, 6),
(561, '2R Building', 2, 36, 5),
(562, '2R Building', 2, 36, 6),
(563, '2R Building', 2, 37, 5),
(564, '2R Building', 2, 37, 6),
(565, '2R Building', 2, 38, 5),
(566, '2R Building', 2, 38, 6),
(567, '2R Building', 2, 39, 5),
(568, '2R Building', 2, 39, 6),
(569, '2R Building', 2, 40, 5),
(570, '2R Building', 2, 40, 6),
(571, '2R Building', 2, 41, 5),
(572, '2R Building', 2, 41, 6),
(573, '2R Building', 2, 42, 5),
(574, '2R Building', 2, 42, 6),
(575, '2R Building', 2, 43, 5),
(576, '2R Building', 2, 43, 6),
(577, '2R Building', 2, 44, 5),
(578, '2R Building', 2, 44, 6),
(579, '2R Building', 2, 45, 5),
(580, '2R Building', 2, 45, 6),
(581, '2R Building', 2, 46, 5),
(582, '2R Building', 2, 46, 6),
(583, '2R Building', 2, 47, 5),
(584, '2R Building', 2, 47, 6),
(585, '2R Building', 2, 48, 5),
(586, '2R Building', 2, 48, 6),
(587, '2R Building', 2, 49, 5),
(588, '2R Building', 2, 49, 6),
(589, '2R Building', 2, 50, 5),
(590, '2R Building', 2, 50, 6),
(591, '2R Building', 2, 51, 5),
(592, '2R Building', 2, 51, 6),
(593, '2R Building', 2, 52, 5),
(594, '2R Building', 2, 52, 6),
(595, '2R Building', 2, 53, 5),
(596, '2R Building', 2, 53, 6),
(597, '2R Building', 2, 54, 5),
(598, '2R Building', 2, 54, 6),
(599, '2R Building', 2, 16, 7),
(600, '2R Building', 2, 16, 8),
(601, '2R Building', 2, 16, 9),
(602, '2R Building', 2, 16, 10),
(603, '2R Building', 2, 16, 11),
(604, '2R Building', 2, 16, 12),
(605, '2R Building', 2, 16, 13),
(606, '2R Building', 2, 16, 14),
(607, '2R Building', 2, 16, 15),
(608, '2R Building', 2, 16, 16),
(609, '2R Building', 2, 16, 17),
(610, '2R Building', 2, 16, 18),
(611, '2R Building', 2, 16, 19),
(612, '2R Building', 2, 17, 7),
(613, '2R Building', 2, 17, 8),
(614, '2R Building', 2, 17, 9),
(615, '2R Building', 2, 17, 10),
(616, '2R Building', 2, 17, 11),
(617, '2R Building', 2, 17, 12),
(618, '2R Building', 2, 17, 13),
(619, '2R Building', 2, 17, 14),
(620, '2R Building', 2, 17, 15),
(621, '2R Building', 2, 17, 16),
(622, '2R Building', 2, 17, 17),
(623, '2R Building', 2, 17, 18),
(624, '2R Building', 2, 17, 19),
(625, '2R Building', 2, 18, 7),
(626, '2R Building', 2, 18, 8),
(627, '2R Building', 2, 18, 9),
(628, '2R Building', 2, 18, 10),
(629, '2R Building', 2, 18, 11),
(630, '2R Building', 2, 18, 12),
(631, '2R Building', 2, 18, 13),
(632, '2R Building', 2, 18, 14),
(633, '2R Building', 2, 18, 15),
(634, '2R Building', 2, 18, 16),
(635, '2R Building', 2, 18, 17),
(636, '2R Building', 2, 18, 18),
(637, '2R Building', 2, 18, 19),
(638, '2R Building', 2, 19, 7),
(639, '2R Building', 2, 19, 8),
(640, '2R Building', 2, 19, 9),
(641, '2R Building', 2, 19, 10),
(642, '2R Building', 2, 19, 11),
(643, '2R Building', 2, 19, 12),
(644, '2R Building', 2, 19, 13),
(645, '2R Building', 2, 19, 14),
(646, '2R Building', 2, 19, 15),
(647, '2R Building', 2, 19, 16),
(648, '2R Building', 2, 19, 17),
(649, '2R Building', 2, 19, 18),
(650, '2R Building', 2, 19, 19),
(651, '2R Building', 2, 20, 7),
(652, '2R Building', 2, 20, 8),
(653, '2R Building', 2, 20, 9),
(654, '2R Building', 2, 20, 10),
(655, '2R Building', 2, 20, 11),
(656, '2R Building', 2, 20, 12),
(657, '2R Building', 2, 20, 13),
(658, '2R Building', 2, 20, 14),
(659, '2R Building', 2, 20, 15),
(660, '2R Building', 2, 20, 16),
(661, '2R Building', 2, 20, 17),
(662, '2R Building', 2, 20, 18),
(663, '2R Building', 2, 20, 19),
(664, '2R Building', 2, 21, 7),
(665, '2R Building', 2, 21, 8),
(666, '2R Building', 2, 21, 9),
(667, '2R Building', 2, 21, 10),
(668, '2R Building', 2, 21, 11),
(669, '2R Building', 2, 21, 12),
(670, '2R Building', 2, 21, 13),
(671, '2R Building', 2, 21, 14),
(672, '2R Building', 2, 21, 15),
(673, '2R Building', 2, 21, 16),
(674, '2R Building', 2, 21, 17),
(675, '2R Building', 2, 21, 18),
(676, '2R Building', 2, 21, 19),
(677, '2R Building', 2, 22, 7),
(678, '2R Building', 2, 22, 8),
(679, '2R Building', 2, 22, 9),
(680, '2R Building', 2, 22, 10),
(681, '2R Building', 2, 22, 11),
(682, '2R Building', 2, 22, 12),
(683, '2R Building', 2, 22, 13),
(684, '2R Building', 2, 22, 14),
(685, '2R Building', 2, 22, 15),
(686, '2R Building', 2, 22, 16),
(687, '2R Building', 2, 22, 17),
(688, '2R Building', 2, 22, 18),
(689, '2R Building', 2, 22, 19),
(690, '2R Building', 2, 23, 7),
(691, '2R Building', 2, 23, 8),
(692, '2R Building', 2, 23, 9),
(693, '2R Building', 2, 23, 10),
(694, '2R Building', 2, 23, 11),
(695, '2R Building', 2, 23, 12),
(696, '2R Building', 2, 23, 13),
(697, '2R Building', 2, 23, 14),
(698, '2R Building', 2, 23, 15),
(699, '2R Building', 2, 23, 16),
(700, '2R Building', 2, 23, 17),
(701, '2R Building', 2, 23, 18),
(702, '2R Building', 2, 23, 19),
(703, '2R Building', 2, 6, 16),
(704, '2R Building', 2, 6, 30),
(705, '2R Building', 2, 7, 16),
(706, '2R Building', 2, 7, 30),
(707, '2R Building', 2, 8, 16),
(708, '2R Building', 2, 8, 30),
(709, '2R Building', 2, 9, 16),
(710, '2R Building', 2, 9, 30),
(711, '2R Building', 2, 10, 16),
(712, '2R Building', 2, 10, 30),
(713, '2R Building', 2, 11, 16),
(714, '2R Building', 2, 11, 19),
(715, '2R Building', 2, 12, 16),
(716, '2R Building', 2, 12, 19),
(717, '2R Building', 2, 13, 16),
(718, '2R Building', 2, 13, 19),
(719, '2R Building', 2, 14, 16),
(720, '2R Building', 2, 14, 19),
(721, '2R Building', 2, 15, 16),
(722, '2R Building', 2, 15, 19),
(723, '2R Building', 2, 19, 22),
(724, '2R Building', 2, 19, 23),
(725, '2R Building', 2, 20, 22),
(726, '2R Building', 2, 20, 23),
(727, '2R Building', 2, 21, 22),
(728, '2R Building', 2, 21, 23),
(729, '2R Building', 2, 22, 22),
(730, '2R Building', 2, 22, 23),
(731, '2R Building', 2, 23, 22),
(732, '2R Building', 2, 23, 23),
(733, '2R Building', 2, 24, 22),
(734, '2R Building', 2, 24, 23),
(735, '2R Building', 2, 25, 22),
(736, '2R Building', 2, 25, 23),
(737, '2R Building', 2, 26, 22),
(738, '2R Building', 2, 26, 23),
(739, '2R Building', 2, 27, 22),
(740, '2R Building', 2, 27, 23),
(741, '2R Building', 2, 11, 30),
(742, '2R Building', 2, 12, 30),
(743, '2R Building', 2, 13, 30),
(744, '2R Building', 2, 14, 30),
(745, '2R Building', 2, 15, 30),
(746, '2R Building', 2, 16, 30),
(747, '2R Building', 2, 17, 30),
(748, '2R Building', 2, 18, 30),
(749, '2R Building', 2, 19, 30),
(750, '2R Building', 2, 20, 30),
(751, '2R Building', 2, 21, 30),
(752, '2R Building', 2, 22, 30),
(753, '2R Building', 2, 23, 30),
(754, '2R Building', 2, 24, 30),
(755, '2R Building', 2, 25, 30),
(756, '2R Building', 2, 26, 30),
(757, '2R Building', 2, 27, 30),
(758, '2R Building', 2, 25, 24),
(759, '2R Building', 2, 25, 25),
(760, '2R Building', 2, 25, 26),
(761, '2R Building', 2, 25, 27),
(762, '2R Building', 2, 25, 28),
(763, '2R Building', 2, 25, 29),
(764, '2R Building', 2, 26, 24),
(765, '2R Building', 2, 26, 25),
(766, '2R Building', 2, 26, 26),
(767, '2R Building', 2, 26, 27),
(768, '2R Building', 2, 26, 28),
(769, '2R Building', 2, 26, 29),
(770, '2R Building', 2, 27, 24),
(771, '2R Building', 2, 27, 25),
(772, '2R Building', 2, 27, 26),
(773, '2R Building', 2, 27, 27),
(774, '2R Building', 2, 27, 28),
(775, '2R Building', 2, 27, 29);

-- --------------------------------------------------------

--
-- Table structure for table `preserveuser`
--

CREATE TABLE `preserveuser` (
  `userID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `search_history`
--

CREATE TABLE `search_history` (
  `id` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `search_term` varchar(255) NOT NULL,
  `search_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_preferences`
--

CREATE TABLE `settings_preferences` (
  `preferenceID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `lightDarkMode` enum('light','dark') NOT NULL DEFAULT 'light',
  `notifications` tinyint(1) NOT NULL DEFAULT 1,
  `language` varchar(50) NOT NULL DEFAULT 'English'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_profile`
--

CREATE TABLE `settings_profile` (
  `profileID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `profilepic` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `special_coordinates`
--

CREATE TABLE `special_coordinates` (
  `coordinateID` int(11) NOT NULL,
  `classroomID` int(11) DEFAULT NULL,
  `facilityID` int(11) DEFAULT NULL,
  `x_coordinate` int(11) NOT NULL,
  `y_coordinate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `special_coordinates`
--

INSERT INTO `special_coordinates` (`coordinateID`, `classroomID`, `facilityID`, `x_coordinate`, `y_coordinate`) VALUES
(22201, 2011, NULL, 54, 33),
(22202, 2012, NULL, 54, 29),
(22203, 2013, NULL, 54, 23),
(22204, 2014, NULL, 54, 20),
(22205, 2014, NULL, 54, 14),
(22206, 2014, NULL, 57, 11),
(22207, 2016, NULL, 57, 11),
(22208, 2016, NULL, 54, 8),
(22209, 2008, NULL, 63, 47),
(22210, 2028, NULL, 32, 6),
(22211, 2029, NULL, 35, 6),
(22212, NULL, 2200, 9, 31),
(22213, NULL, 2200, 20, 31),
(22214, NULL, 2200, 31, 31),
(22215, NULL, 2203, 38, 31),
(22216, NULL, 2204, 49, 33),
(22217, NULL, 2205, 49, 38),
(22218, NULL, 2206, 51, 44),
(22219, NULL, 2207, 60, 44),
(22220, NULL, 2209, 56, 42),
(22221, NULL, 2208, 63, 42),
(22222, NULL, 2226, 66, 40),
(22223, NULL, 2227, 64, 40),
(22224, NULL, NULL, 36, 5),
(22225, NULL, 2229, 33, 5),
(22226, NULL, 2230, 33, 5),
(22227, NULL, 2215, 16, 8),
(22228, NULL, 2214, 16, 8),
(22229, NULL, 2216, 23, 19),
(22230, NULL, 2225, 23, 15),
(22231, NULL, 2224, 23, 12),
(22232, NULL, 2223, 23, 9),
(22233, NULL, 2222, 27, 6),
(22234, NULL, 2221, 51, 9),
(22235, NULL, NULL, 51, 9),
(22236, NULL, 2220, 29, 22),
(22237, NULL, 2219, 29, 22),
(22238, NULL, 2218, 29, 22),
(22239, NULL, 2217, 29, 22),
(22240, NULL, 2231, 28, 27),
(22241, NULL, 2232, 11, 19),
(22242, NULL, 2232, 25, 27),
(22243, NULL, 2210, 57, 11),
(22244, NULL, 2211, 53, 5),
(22245, NULL, 2212, 46, 5),
(33310, 3006, NULL, 4, 40),
(33312, NULL, 3209, 4, 44),
(33320, 3004, NULL, 15, 36),
(33321, 3010, NULL, 18, 43),
(33324, 3021, NULL, 44, 24),
(33326, 3002, NULL, 28, 36),
(33329, 3019, NULL, 58, 33),
(33330, NULL, 3206, 31, 27),
(33331, NULL, 3205, 29, 5),
(33332, 3032, NULL, 15, 17),
(33334, 3014, NULL, 43, 43),
(33335, 3024, NULL, 61, 17),
(33337, 3020, NULL, 44, 23),
(33339, 3026, NULL, 42, 10),
(33340, NULL, 3202, 65, 42),
(33341, NULL, 3201, 65, 39),
(33342, 3023, NULL, 58, 16),
(33343, 3005, NULL, 8, 36),
(33345, 3008, NULL, 6, 43),
(33346, NULL, 3204, 31, 5),
(33347, 3034, NULL, 11, 17),
(33348, 3015, NULL, 41, 43),
(33349, 3018, NULL, 61, 34),
(33351, 3011, NULL, 15, 36),
(33353, 3015, NULL, 41, 30),
(33355, 3012, NULL, 31, 43),
(33356, NULL, 3200, 65, 37),
(33358, 3020, NULL, 61, 28),
(33359, 3031, NULL, 24, 17),
(33361, 3025, NULL, 61, 12),
(33364, 3013, NULL, 28, 43),
(33366, 3028, NULL, 40, 21),
(33367, 3010, NULL, 11, 43),
(33368, 3017, NULL, 51, 43),
(33370, NULL, 3207, 13, 5),
(33372, 3016, NULL, 52, 43),
(33374, 3033, NULL, 17, 17),
(33377, 3009, NULL, 8, 36),
(33378, 3030, NULL, 24, 5),
(33381, 3003, NULL, 19, 36),
(33383, NULL, 3210, 12, 17),
(33385, 3023, NULL, 58, 17),
(33389, 3012, NULL, 24, 43),
(33390, NULL, 3203, 29, 5),
(33392, 3027, NULL, 39, 11),
(33395, 3032, NULL, 23, 17),
(33398, NULL, 3211, 59, 45),
(33399, 3022, NULL, 61, 23);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `department` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `studentID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `faculty` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `userType` enum('student','staff','admin') NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `number` varchar(20) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `lastLoginDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `salt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

CREATE TABLE `usertype` (
  `userTypeID` int(8) NOT NULL,
  `userTypeName` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`adminID`),
  ADD UNIQUE KEY `userID` (`userID`);

--
-- Indexes for table `buildings`
--
ALTER TABLE `buildings`
  ADD PRIMARY KEY (`buildingID`),
  ADD UNIQUE KEY `building_name` (`building_name`);

--
-- Indexes for table `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`classroomID`);

--
-- Indexes for table `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`facilityID`);

--
-- Indexes for table `paths`
--
ALTER TABLE `paths`
  ADD PRIMARY KEY (`pathID`);

--
-- Indexes for table `preserveuser`
--
ALTER TABLE `preserveuser`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `search_history`
--
ALTER TABLE `search_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `settings_preferences`
--
ALTER TABLE `settings_preferences`
  ADD PRIMARY KEY (`preferenceID`),
  ADD UNIQUE KEY `userID` (`userID`);

--
-- Indexes for table `settings_profile`
--
ALTER TABLE `settings_profile`
  ADD PRIMARY KEY (`profileID`),
  ADD UNIQUE KEY `userID` (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `special_coordinates`
--
ALTER TABLE `special_coordinates`
  ADD PRIMARY KEY (`coordinateID`),
  ADD KEY `classroomID` (`classroomID`),
  ADD KEY `facilityID` (`facilityID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffID`),
  ADD UNIQUE KEY `userID` (`userID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentID`),
  ADD UNIQUE KEY `userID` (`userID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `paths`
--
ALTER TABLE `paths`
  MODIFY `pathID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=776;

--
-- AUTO_INCREMENT for table `search_history`
--
ALTER TABLE `search_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings_preferences`
--
ALTER TABLE `settings_preferences`
  MODIFY `preferenceID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings_profile`
--
ALTER TABLE `settings_profile`
  MODIFY `profileID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `admins_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `preserveuser`
--
ALTER TABLE `preserveuser`
  ADD CONSTRAINT `preserveuser_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `admins` (`adminID`);

--
-- Constraints for table `search_history`
--
ALTER TABLE `search_history`
  ADD CONSTRAINT `search_history_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `settings_preferences`
--
ALTER TABLE `settings_preferences`
  ADD CONSTRAINT `settings_preferences_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `settings_profile`
--
ALTER TABLE `settings_profile`
  ADD CONSTRAINT `settings_profile_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `special_coordinates`
--
ALTER TABLE `special_coordinates`
  ADD CONSTRAINT `special_coordinates_ibfk_1` FOREIGN KEY (`classroomID`) REFERENCES `classrooms` (`classroomID`) ON DELETE CASCADE,
  ADD CONSTRAINT `special_coordinates_ibfk_2` FOREIGN KEY (`facilityID`) REFERENCES `facilities` (`facilityID`) ON DELETE CASCADE;

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
