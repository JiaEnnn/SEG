let profileDropdownList = document.querySelector(".profile-dropdown-list");
let btn = document.querySelector(".profile-dropdown-btn");

let classList = profileDropdownList.classList;

const toggle = () => classList.toggle("active");

window.addEventListener("click", function (e) {
  if (!btn.contains(e.target)) classList.remove("active");
});

document.addEventListener("DOMContentLoaded", function () {
  const userLang = localStorage.getItem("language") || "en";

  fetch(`./locales/${userLang}.json`)
      .then(response => response.json())
      .then(translations => {
          document.querySelector("a[href='settings.html']").textContent = translations.settings;
          document.querySelector("a[href='profile.html']").textContent = translations.profile;
          document.querySelector("a[href='inbox.html']").textContent = translations.inbox;
          document.querySelector("a[href='help.html']").textContent = translations.help;
          document.querySelector("a[href='#']").textContent = translations.logout;

          document.querySelectorAll(".navbar-list li a").forEach((link) => {
              if (translations[link.textContent.toLowerCase()]) {
                  link.textContent = translations[link.textContent.toLowerCase()];
              }
          });
      })
      .catch(error => console.error("Error loading language file:", error));
});

document.addEventListener("DOMContentLoaded", function () {
    fetch('http://localhost:5000/api/your-endpoint')
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => console.log('Fetched data:', data))
      .catch(error => console.error('Error fetching data:', error));
  });
  
  document.addEventListener("DOMContentLoaded", () => {
    const floor2Btn = document.getElementById("floor-2");
    const floor3Btn = document.getElementById("floor-3");
    const floorPlanDrawing = document.getElementById("floorPlanDrawing");
    const floorPlanWithCoords = document.getElementById("floorPlanWithCoords");
  
    // Switch floor plan when buttons are clicked
    function changeFloor(level) {
      if (level === 2) {
        floorPlanDrawing.src = "floorplan/floorPlanDrawing 2F.png";
        floorPlanWithCoords.src = "floorplan/floorPlanWithCoords 2F.png";
        floor2Btn.classList.add("active");
        floor3Btn.classList.remove("active");
      } else {
        floorPlanDrawing.src = "floorplan/floorPlanDrawing 3F.png";
        floorPlanWithCoords.src = "floorplan/floorPlanWithCoords 3F.png";
        floor3Btn.classList.add("active");
        floor2Btn.classList.remove("active");
      }
    }
  
    floor2Btn.addEventListener("click", () => changeFloor(2));
    floor3Btn.addEventListener("click", () => changeFloor(3));
  });
  

  document.addEventListener("DOMContentLoaded", function () {
    const floorBtns = document.querySelectorAll(".floor-btn");
    const floorPlanWithCoords = document.getElementById("floorPlanWithCoords");
    const floorPlanDrawing = document.getElementById("floorPlanDrawing");
    const startLocationBtn = document.getElementById("start-location");
    const endLocationBtn = document.getElementById("end-location");

    let selectedStart = null;
    let selectedEnd = null;
    
    // Floor switching functionality
    floorBtns.forEach(btn => {
        btn.addEventListener("click", function () {
            floorBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            updateFloorPlan(btn.id);
        });
    });

    function updateFloorPlan(floorId) {
        const floorNumber = floorId.split("-")[1];
        floorPlanWithCoords.src = `floorplan/floorPlanWithCoords ${floorNumber}F.png`;
        floorPlanDrawing.src = `floorplan/floorPlanDrawing ${floorNumber}F.png`;
    }

    // Handle location selection
    startLocationBtn.addEventListener("click", () => {
        selectedStart = prompt("Enter Start Location (e.g., Room Number)");
        fetchLocation(selectedStart, "start");
    });
    
    endLocationBtn.addEventListener("click", () => {
        selectedEnd = prompt("Enter End Location (e.g., Room Number)");
        fetchLocation(selectedEnd, "end");
    });

    function fetchLocation(location, type) {
        fetch(`/api/getLocation?name=${location}`)
            .then(res => res.json())
            .then(data => {
                if (data) {
                    console.log(`${type} Location:`, data);
                    alert(`${type} location set to ${data.room_number || data.facility_number}`);
                } else {
                    alert("Location not found.");
                }
            })
            .catch(err => console.error("Error fetching location:", err));
    }

    // Fetch data on load
    function fetchInitialData() {
        fetch("/api/getAllLocations")
            .then(response => response.json())
            .then(data => console.log("Fetched Locations:", data))
            .catch(error => console.error("Error fetching initial data:", error));
    }

    fetchInitialData();
});