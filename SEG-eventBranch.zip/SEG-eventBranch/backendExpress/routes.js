const express = require('express');
const router = express.Router();
const db = require('./connectDB');
require('dotenv').config({ path: './connectDB.env' });

// Define the route
router.get('/api/your-endpoint', (req, res) => {
    res.json({ message: "API is working!" });
});

// Route: GET /database - Retrieve all users
router.get('/database', async (req, res) => {
    try {
        const [results] = await db.sequelize.query(`
            SELECT userID, userType, email, number, createdAt, updatedAt, lastLoginDate 
            FROM users;
        `);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Route: GET /all-tables - Get all tables separately
router.get('/all-tables', async (req, res) => {
    const queries = {
        users: 'SELECT * FROM users',
        students: 'SELECT * FROM students',
        staff: 'SELECT * FROM staff',
        admins: 'SELECT * FROM admins',
        classrooms: 'SELECT * FROM classrooms',
        facilities: 'SELECT * FROM facilities',
        special_coordinates: 'SELECT * FROM special_coordinates',
        paths: 'SELECT * FROM paths',
        emergency_routes: 'SELECT * FROM emergency_routes',
        buildings: 'SELECT * FROM buildings'
    };

    try {
        let responseData = {};
        for (let table in queries) {
            const [results] = await db.sequelize.query(queries[table]);
            responseData[table] = results;
        }
        res.json(responseData);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Update user language
router.post('/update-language', async (req, res) => {
    const { id, language } = req.body;
    if (!id || !language) return res.status(400).json({ error: "Missing required fields" });

    try {
        await db.sequelize.query(
            `UPDATE settings_preferences SET language = ? WHERE userID = ?`,
            { replacements: [language, id] }
        );
        res.json({ message: "Language updated successfully" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get user language
router.get('/get-language/:id', async (req, res) => {
    const { id } = req.params;

    try {
        const [results] = await db.sequelize.query(
            `SELECT language FROM settings_preferences WHERE userID = ?`,
            { replacements: [id] }
        );
        if (results.length === 0) return res.status(404).json({ error: "User not found" });

        res.json({ language: results[0].language });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get search history
router.get('/search-history/:id', async (req, res) => {
    const { id } = req.params;

    try {
        const [results] = await db.sequelize.query(
            `SELECT * FROM search_history WHERE userID = ? ORDER BY search_date DESC`,
            { replacements: [id] }
        );
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get all buildings
router.get('/buildings', async (req, res) => {
    try {
        const [results] = await db.sequelize.query(`SELECT * FROM buildings`);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Fetch all classrooms on a specific floor
router.get('/classrooms/:building/:floor', async (req, res) => {
    try {
        const { building, floor } = req.params;
        const [results] = await db.sequelize.query(
            `SELECT * FROM classrooms WHERE building_name = ? AND floor_number = ?`,
            { replacements: [building, floor] }
        );
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Fetch all facilities on a specific floor
router.get('/facilities/:building/:floor', async (req, res) => {
    try {
        const { building, floor } = req.params;
        const [results] = await db.sequelize.query(
            `SELECT * FROM facilities WHERE building_name = ? AND floor_number = ?`,
            { replacements: [building, floor] }
        );
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Fetch all paths on a specific floor
router.get('/paths/:building/:floor', async (req, res) => {
    try {
        const { building, floor } = req.params;
        const [results] = await db.sequelize.query(
            `SELECT * FROM paths WHERE building_name = ? AND floor_number = ?`,
            { replacements: [building, floor] }
        );
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Fetch special coordinates by clicked position
router.post('/special-coordinates', async (req, res) => {
    try {
        const { x, y, building, floor } = req.body;
        const [results] = await db.sequelize.query(
            `SELECT * FROM special_coordinates 
             WHERE x_coordinate = ? AND y_coordinate = ? 
             AND (classroomID IS NOT NULL OR facilityID IS NOT NULL)`,
            { replacements: [x, y] }
        );
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


module.exports = router;
