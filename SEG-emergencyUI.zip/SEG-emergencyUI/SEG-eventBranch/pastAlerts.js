document.addEventListener("DOMContentLoaded", function () {
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
    }

    const messages = [

        {
            sender: "Fire Emergency",
            time: "17 February",
            content: "Fire Detected at 2R010. Evacuate immediately using the nearest exit. Avoid elevators."
        },
        {
            sender: "Severe Weather Warning",
            time: "3 January",
            content: "Flooding at Eco Botanic Area. Heavy rainfall expected. Do not attempt to drive through flooded roads."
        },
        
    ];

    const inboxItems = document.querySelectorAll(".inbox-item");
    const messageBox = document.querySelector(".message-content");
    
    inboxItems.forEach((item, index) => {
        item.addEventListener("click", function () {
            messageBox.innerHTML = `<strong>${messages[index].sender}</strong> - ${messages[index].time}<br><br>${messages[index].content}`;
        });
    });

});
