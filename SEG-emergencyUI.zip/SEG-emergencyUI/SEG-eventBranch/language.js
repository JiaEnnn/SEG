// Language translation script
document.addEventListener("DOMContentLoaded", function () {
    const userLang = localStorage.getItem("language") || "en";

    fetch(`./locales/${userLang}.json`)
        .then(response => response.json())
        .then(translations => {
            // Update specific links using href attributes
            const linksToTranslate = {
                "settings.html": "settings",
                "profile.html": "profile",
                "inbox.html": "inbox",
                "help.html": "help",
                "#": "logout"
            };

            Object.entries(linksToTranslate).forEach(([href, key]) => {
                let link = document.querySelector(`a[href='${href}']`);
                if (link && translations[key]) {
                    let iconHTML = link.querySelector("i")?.outerHTML || ""; // Preserve icon
                    link.innerHTML = `${iconHTML} ${translations[key]}`;
                }
            });

            // Translate all navbar links while preserving icons
            document.querySelectorAll(".navbar-list li a").forEach((link) => {
                let key = link.textContent.trim().toLowerCase();

                if (translations[key]) {
                    let iconHTML = link.querySelector("i")?.outerHTML || ""; // Preserve icon
                    link.innerHTML = `${iconHTML} ${translations[key]}`;
                    console.log(`Translating "${key}" to "${translations[key]}"`);
                } else {
                    console.warn(`No translation found for: "${key}"`);
                }
            });
        })
        .catch(error => console.error("Error loading language file:", error));
});
