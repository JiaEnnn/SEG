document.addEventListener("DOMContentLoaded", function () {
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
    }

    const messages = [

        {
            sender: "Fire Emergency",
            time: "19 February",
            content: "Fire Detected at 2R010. \nEvacuate immediately using the nearest exit."
        },
        
    ];

    const inboxItems = document.querySelectorAll(".inbox-item");
    const messageBox = document.querySelector(".message-content");
    
    inboxItems.forEach((item, index) => {
        item.addEventListener("click", function () {
            messageBox.innerHTML = `<strong>${messages[index].sender}</strong> - ${messages[index].time}<br><br>${messages[index].content}`;
        });
    });

});
