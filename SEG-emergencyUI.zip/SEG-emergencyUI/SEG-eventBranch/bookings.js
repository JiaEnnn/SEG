document.addEventListener("DOMContentLoaded", function() {
    // Dark mode check
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
    }

    // UI Elements
    const floor2Btn = document.getElementById("booking-floor-2");
    const floor3Btn = document.getElementById("booking-floor-3");
    const floorPlanDrawing = document.getElementById("booking-floorPlanDrawing");
    const floorPlanWithCoords = document.getElementById("booking-floorPlanWithCoords");
    const floorBtns = document.querySelectorAll(".booking-floor-btn");
    const submitButton = document.getElementById("booking-submit");
    
    // Configuration
    const FLOOR_IMAGE_DIMENSIONS = {
        level2: { width: 4350, height: 3165 },
        level3: { width: 4350, height: 3165 }
    };

    const GRID_SIZES = {
        level2: { x: 68, y: 50 },
        level3: { x: 68, y: 50 }
    };

    // State variables
    let highlightsContainer = document.querySelector(".booking-grid-highlights");
    let selectedRoom = null;
    let currentFloor = 2;
    let bookedRooms = []; // Stores already booked rooms

    // Initialize highlights container
    if (!highlightsContainer) {
        highlightsContainer = document.createElement("div");
        highlightsContainer.className = "booking-grid-highlights";
        document.querySelector(".booking-floorplan").appendChild(highlightsContainer);
    }

    // Load already booked rooms
    function loadBookedRooms() {
        fetch(`/api/bookings?floor=${currentFloor}`)
            .then(response => response.json())
            .then(data => {
                bookedRooms = data;
                renderRoomStatuses();
            });
    }

    // Render room statuses (grey=available, red=booked)
    function renderRoomStatuses() {
        // Clear existing highlights
        highlightsContainer.innerHTML = '';
        
        // Render booked rooms as red
        bookedRooms.forEach(room => {
            if (room.floor === currentFloor) {
                createRoomHighlight(room, 'booked');
            }
        });
    }

    // Create a room highlight
    function createRoomHighlight(roomData, status) {
        const { cellWidth, cellHeight } = getCellSize();
        const highlight = document.createElement("div");
        highlight.className = `room-highlight ${status}`;
        
        const width = (roomData.x_max - roomData.x_min + 1) * cellWidth;
        const height = (roomData.y_max - roomData.y_min + 1) * cellHeight;
        
        highlight.style.left = `${roomData.x_min * cellWidth}px`;
        highlight.style.top = `${roomData.y_min * cellHeight}px`;
        highlight.style.width = `${width}px`;
        highlight.style.height = `${height}px`;
        
        if (roomData.room_number) {
            highlight.innerHTML = `<span class="room-label">${roomData.room_number}</span>`;
        }
        
        highlightsContainer.appendChild(highlight);
        return highlight;
    }

    // Floor switching function
    function changeFloor(level) {
        currentFloor = level;
        floorPlanDrawing.src = `floorplan/floorPlanDrawing ${level}F.jpg`;
        floorPlanWithCoords.src = `floorplan/floorPlanWithCoords ${level}F.jpg`;
        
        floorBtns.forEach(btn => {
            btn.classList.toggle("active", parseInt(btn.dataset.floor) === level);
        });
        
        clearRoomSelection();
        loadBookedRooms();
    }

    // Helper functions
    function getDisplayedSize() {
        return {
            width: floorPlanWithCoords.clientWidth,
            height: floorPlanWithCoords.clientHeight
        };
    }

    function getCellSize() {
        const { width: displayWidth, height: displayHeight } = getDisplayedSize();
        const grid = GRID_SIZES[`level${currentFloor}`];
        const imgDim = FLOOR_IMAGE_DIMENSIONS[`level${currentFloor}`];
        
        const scaleX = displayWidth / imgDim.width;
        const scaleY = displayHeight / imgDim.height;
        
        return {
            cellWidth: imgDim.width / grid.x,
            cellHeight: imgDim.height / grid.y,
            scaleX,
            scaleY
        };
    }

    function clearRoomSelection() {
        if (selectedRoom) {
            selectedRoom.element.remove();
            selectedRoom = null;
        }
    }

    // Room selection from floor plan click
    floorPlanWithCoords.addEventListener("click", async (event) => {
        const { cellWidth, cellHeight, scaleX, scaleY } = getCellSize();
        const rect = floorPlanWithCoords.getBoundingClientRect();
        
        const imgX = (event.clientX - rect.left) / scaleX;
        const imgY = (event.clientY - rect.top) / scaleY;
        
        const gridX = Math.floor(imgX / cellWidth);
        const gridY = Math.floor(imgY / cellHeight);
        
        try {
            const response = await fetch(`/api/getLocationByCoords?x=${gridX}&y=${gridY}&floor=${currentFloor}`);
            const locationData = await response.json();
            
            if (!locationData) {
                alert("No room found at this location");
                return;
            }

            // Check if room is already booked
            const isBooked = bookedRooms.some(room => 
                room.room_number === locationData.room_number && 
                room.floor === currentFloor
            );
            
            if (isBooked) {
                alert("This room is already booked for the selected time");
                return;
            }

            clearRoomSelection();
            
            // Highlight the selected room in green
            const highlight = createRoomHighlight(locationData, 'selected');
            
            selectedRoom = {
                element: highlight,
                details: locationData
            };
            
        } catch (error) {
            console.error("Error:", error);
            alert("Failed to select room");
        }
    });

    // Handle Booking Submission
    submitButton.addEventListener("click", async () => {
        const date = document.getElementById("date").value;
        const time = document.getElementById("time").value;
        
        if (!date || !time) {
            alert("Please select a date and time.");
            return;
        }
        
        if (!selectedRoom) {
            alert("Please select a room by clicking on the floor plan.");
            return;
        }

        const bookingDetails = {
            date,
            time,
            floor: currentFloor,
            room_number: selectedRoom.details.room_number,
            coordinates: {
                x_min: selectedRoom.details.x_min,
                x_max: selectedRoom.details.x_max,
                y_min: selectedRoom.details.y_min,
                y_max: selectedRoom.details.y_max
            },
            status: 'confirmed'
        };

        try {
            const response = await fetch('/api/bookings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bookingDetails)
            });
            
            if (!response.ok) throw new Error('Booking failed');
            
            const result = await response.json();
            
            // Change selection to booked (red)
            selectedRoom.element.classList.remove('selected');
            selectedRoom.element.classList.add('booked');
            bookedRooms.push(bookingDetails);
            
            alert(`Booking confirmed for Room ${bookingDetails.room_number} on ${date} at ${time}`);
        } catch (error) {
            console.error("Booking error:", error);
            alert("Failed to submit booking. Please try again.");
        }
    });

    // Initialize
    floor2Btn.addEventListener("click", () => changeFloor(2));
    floor3Btn.addEventListener("click", () => changeFloor(3));
    changeFloor(2);
});