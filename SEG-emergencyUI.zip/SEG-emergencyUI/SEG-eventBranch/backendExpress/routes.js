const express = require('express');
const router = express.Router();
const pool = require('./connectDB');
require('dotenv').config({ path: './connectDB.env' });

// Check if API is working
router.get('/your-endpoint', (req, res) => {
    res.json({ message: "API is working!" });
});

// Get all users (fetching)
router.get('/users', async (req, res) => {
    try {
        const [results] = await pool.query(`
            SELECT userID, userType, email, number, createdAt, updatedAt, lastLoginDate 
            FROM users
        `);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get all tables (fetching)
router.get('/all-tables', async (req, res) => {
    const tables = [
        'users', 'students', 'staff', 'admins', 
        'classrooms', 'facilities', 'special_coordinates',
        'paths', 'emergency_routes', 'buildings'
    ];

    try {
        const responseData = {};
        for (const table of tables) {
            const [results] = await pool.query(`SELECT * FROM ${table}`);
            responseData[table] = results;
        }
        res.json(responseData);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get all buildings
router.get('/buildings', async (req, res) => {
    try {
        const [results] = await pool.query('SELECT * FROM buildings');
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get location by coordinates
router.get('/getLocationByCoords', async (req, res) => {
    console.log('Received query:', req.query); //cors

    // Validate query parameters
    if (!req.query.x || !req.query.y || !req.query.floor) {
        return res.status(400).json({ 
            error: "Missing required parameters: x, y, floor" 
        });
    }

    try {
        const { x, y, floor } = req.query;
        
        // Convert to numbers
        const xCoord = Number(x);
        const yCoord = Number(y);
        const floorNum = Number(floor);
        
        // Check classrooms first
        const [classroom] = await pool.query(`
            SELECT *, 'classroom' as type FROM classrooms 
            WHERE floor_number = ? 
            AND ? BETWEEN x_min AND x_max 
            AND ? BETWEEN y_min AND y_max
            LIMIT 1
        `, [floor, x, y]);

        if (classroom.length > 0) {
            return res.json(classroom[0]);
        }

        // Check facilities if no classroom found
        const [facility] = await pool.query(`
            SELECT *, 'facility' as type FROM facilities 
            WHERE floor_number = ? 
            AND ? BETWEEN x_min AND x_max 
            AND ? BETWEEN y_min AND y_max
            LIMIT 1
        `, [floor, x, y]);

        if (facility.length > 0) {
            return res.json(facility[0]);
        }

        res.status(404).json(null);
    } catch (err) {
        console.error('Full error:', err); //cors
        res.status(500).json({ 
            error: err.message,
            stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
        });
    }
});

// Get path between points
router.get('/getPath', async (req, res) => {
    try {
        const { startX, startY, endX, endY, floor } = req.query;
        
        const [path] = await pool.query(`
            SELECT * FROM paths 
            WHERE floor_number = ?
            ORDER BY SQRT(POW(x_coordinate-?, 2) + POW(y_coordinate-?, 2))
            LIMIT 20
        `, [floor, startX, startY]);

        res.json({ path });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get all classrooms in a building and floor
router.get('/classrooms/:building/:floor', async (req, res) => {
    try {
        const { building, floor } = req.params;
        const [results] = await pool.query(
            `SELECT * FROM classrooms WHERE building_name = ? AND floor_number = ?`,
            [building, floor]
        );
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get all facilities in a building and floor
router.get('/facilities/:building/:floor', async (req, res) => {
    try {
        const { building, floor } = req.params;
        const [results] = await pool.query(
            `SELECT * FROM facilities WHERE building_name = ? AND floor_number = ?`,
            [building, floor]
        );
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get all paths in a building and floor
router.get('/paths/:building/:floor', async (req, res) => {
    try {
        const { building, floor } = req.params;
        const [results] = await pool.query(
            `SELECT * FROM paths WHERE building_name = ? AND floor_number = ?`,
            [building, floor]
        );
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get special coordinates by clicked position
router.post('/special-coordinates', async (req, res) => {
    try {
        const { x, y } = req.body;
        const [results] = await pool.query(
            `SELECT * FROM special_coordinates 
             WHERE x_coordinate = ? AND y_coordinate = ? 
             AND (classroomID IS NOT NULL OR facilityID IS NOT NULL)`,
            [x, y]
        );
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});



// Update user language
router.post('/update-language', async (req, res) => {
    const { id, language } = req.body;
    if (!id || !language) return res.status(400).json({ error: "Missing required fields" });

    try {
        await pool.query(
            `UPDATE settings_preferences SET language = ? WHERE userID = ?`,
            [language, id]
        );
        res.json({ message: "Language updated successfully" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get user language
router.get('/get-language/:id', async (req, res) => {
    const { id } = req.params;

    try {
        const [results] = await pool.query(
            `SELECT language FROM settings_preferences WHERE userID = ?`,
            [id]
        );
        if (results.length === 0) return res.status(404).json({ error: "User not found" });

        res.json({ language: results[0].language });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get search history
// router.get('/search-history/:id', async (req, res) => {
//     const { id } = req.params;

//     try {
//         const [results] = await pool.query(
//             `SELECT * FROM search_history WHERE userID = ? ORDER BY search_date DESC`,
//             [id]
//         );
//         res.json(results);
//     } catch (err) {
//         res.status(500).json({ error: err.message });
//     }
// });

module.exports = router;