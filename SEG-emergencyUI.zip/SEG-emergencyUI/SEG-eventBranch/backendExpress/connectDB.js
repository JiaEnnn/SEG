'use strict';

require('dotenv').config({ path: './connectDB.env' });
const { Sequelize } = require("sequelize");
const mysql = require('mysql2/promise'); // Add mysql2 for raw queries

// Sequelize configuration (for your teammate)
const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    dialect: "mysql",
    pool: {
      max: 3,
      min: 0,
      acquire: 30000,
      idle: 10000,
    },
  }
);

// MySQL2 connection pool (for your raw queries)
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Test both connections
Promise.all([
  sequelize.authenticate(),
  pool.getConnection().then(conn => conn.release())
])
.then(() => {
  console.log("Database connections established successfully");
})
.catch(err => {
  console.error("Unable to connect to the database:", err);
});

const db = {
  // Sequelize objects (for your teammate)
  sequelize,
  Sequelize,
  
  // Raw query interface (for you)
  pool,
  rawQuery: async (sql, params) => {
    const [rows] = await pool.query(sql, params);
    return rows;
  }
};

module.exports = db;

// 'use strict';

// // require('dotenv').config();
// require('dotenv').config({ path: './connectDB.env' });
// const { Sequelize } = require("sequelize");
// const DB_CONFIG = require("./db.config");

// // Initialize Sequelize connection
// const sequelize = new Sequelize(
//     process.env.DB_NAME,      // Database Name
//     process.env.DB_USER,      // Username
//     process.env.DB_PASSWORD,  // Password
//     {
//         // host: process.env.DB_HOST,
//         // dialect: DB_CONFIG.dialect,
//         // operatorsAliases: false,
//         // pool: {
//         //   max: DB_CONFIG.pool.max,
//         //   min: DB_CONFIG.pool.min,
//         //   acquire: DB_CONFIG.pool.acquire,
//         //   idle: DB_CONFIG.pool.idle,
//         host: process.env.DB_HOST,
//         dialect: "mysql",
//         pool: {
//           max: 3,
//           min: 0,
//           acquire: 30000,
//           idle: 10000,
//         },
//       }
//     );
    
//     sequelize
//       .authenticate()
//       .then(() => {
//         console.log("Connection has been established successfully.");
//       })
//       .catch(err => {
//         console.error("Unable to connect to the database: ", err);
//       });
    
//     const db = {};
    
//     db.sequelize = sequelize;
//     db.Sequelize = Sequelize;
    
//     module.exports = db;