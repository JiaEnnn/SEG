document.addEventListener("DOMContentLoaded", () => {
    try {
        // UI Elements - add null checks
        const floor2Btn = document.getElementById("floor-2");
        const floor3Btn = document.getElementById("floor-3");
        const floorPlanDrawing = document.getElementById("floorPlanDrawing");
        const floorPlanWithCoords = document.getElementById("floorPlanWithCoords");
        const floorBtns = document.querySelectorAll(".floor-btn");
        const floorplanContainer = document.querySelector(".floorplan");

        if (!floor2Btn || !floor3Btn || !floorPlanDrawing || !floorPlanWithCoords || !floorplanContainer) {
            throw new Error("Required DOM elements not found");
        }

        const FLOOR_IMAGE_DIMENSIONS = {
            level2: { width: 4350, height: 3165 },
            level3: { width: 4350, height: 3165 }
        };

        // Highlights container setup with better error handling
        let highlightsContainer = document.querySelector(".grid-highlights");
        if (!highlightsContainer) {
            highlightsContainer = document.createElement("div");
            highlightsContainer.className = "grid-highlights";
            floorplanContainer.appendChild(highlightsContainer);
        } else {
            highlightsContainer.innerHTML = '';
        }

        // State variables
        let currentFloor = 2;
        let selectingStart = false;
        let selectingEnd = false;
        let selectedStart = null;
        let selectedEnd = null;
        
        // Grid configuration
        const GRID_SIZES = {
            default: { x: 10, y: 10 },
            level2: { x: 68, y: 50 },
            level3: { x: 68, y: 50 }
        };
        
        // Floor switching
        function changeFloor(level) {
            currentFloor = level;
            floorPlanDrawing.src = `/floorplan/floorPlanDrawing ${level}F.jpg`;
            floorPlanWithCoords.src = `/floorplan/floorPlanWithCoords ${level}F.jpg`;
            floor2Btn.classList.toggle("active", level === 2);
            floor3Btn.classList.toggle("active", level === 3);
        }
        
        // Helper functions
        function getDisplayedSize() {
            return {
                width: floorPlanWithCoords.clientWidth,
                height: floorPlanWithCoords.clientHeight
            };
        }
        
        function getCellSize() {
            const { width: displayWidth, height: displayHeight } = getDisplayedSize();
            const grid = GRID_SIZES[currentFloor === 2 || currentFloor === 3 ? "level2" : "default"];
            const imgDim = FLOOR_IMAGE_DIMENSIONS[currentFloor === 2 || currentFloor === 3 ? "level2" : "level3"];
            
            const scaleX = displayWidth / imgDim.width;
            const scaleY = displayHeight / imgDim.height;
            
            return {
                cellWidth: imgDim.width / grid.x,
                cellHeight: imgDim.height / grid.y,
                scaleX,
                scaleY
            };
        }

        // Image load handlers
        floorPlanWithCoords.onload = function() {
            console.log("Overlay image loaded, dimensions:", this.naturalWidth, "x", this.naturalHeight);
        };

        floorPlanDrawing.onload = function() {
            console.log("Base image loaded, dimensions:", this.naturalWidth, "x", this.naturalHeight);
        };

        // Click handler for floor plan
        floorPlanWithCoords.addEventListener("click", (event) => {
            const { cellWidth, cellHeight, scaleX, scaleY } = getCellSize();
            const rect = floorPlanWithCoords.getBoundingClientRect();
            
            const imgX = (event.clientX - rect.left) / scaleX;
            const imgY = (event.clientY - rect.top) / scaleY;
            
            const gridX = Math.floor(imgX / cellWidth);
            const gridY = Math.floor(imgY / cellHeight);
            
            console.log(`Clicked at: Image(${imgX}, ${imgY}) => Grid(${gridX}, ${gridY})`);
            fetchLocationByCoords(gridX, gridY);
        });

        function fetchLocationByCoords(gridX, gridY) {
            console.log(`Fetching location for: x=${gridX}, y=${gridY}, floor=${currentFloor}`);

            fetch(`/api/getLocationByCoords?x=${gridX}&y=${gridY}&floor=${currentFloor}`, {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(async res => {
                const text = await res.text();
                try {
                    const data = JSON.parse(text);
                    if (!res.ok) {
                        throw new Error(data.error || 'Invalid response from server');
                    }
                    return data;
                } catch (e) {
                    throw new Error(text || 'Invalid server response');
                }
            })
            .then(apiData => {
                console.log("API Response:", apiData);
                if (apiData) {
                    const locationData = {
                        room_number: apiData.room_number || (apiData.type === 'classroom' ? apiData.room_number : null),
                        facility_number: apiData.facility_number || (apiData.type === 'facility' ? apiData.facility_number : null),
                        x_min: apiData.x_min,
                        x_max: apiData.x_max,
                        y_min: apiData.y_min,
                        y_max: apiData.y_max,
                    };

                    if (selectingStart) {
                        selectedStart = locationData;
                        highlightArea(locationData, true, false);
                        alert(`Start location set to ${locationData.room_number || locationData.facility_number || 'selected point'}`);
                        selectingStart = false;
                    } else if (selectingEnd) {
                        selectedEnd = locationData;
                        highlightArea(locationData, false, true);
                        alert(`End location set to ${locationData.room_number || locationData.facility_number || 'selected point'}`);
                        selectingEnd = false;
                    } else {
                        highlightArea(locationData);
                    }
                } else {
                    alert("Invalid location. Try again.");
                }
            })
            .catch(err => {
                console.error("Full error details:", err);
                const errorMsg = err.message.includes('<!DOCTYPE html>') 
                    ? 'Server returned an error page. Please try again later.'
                    : err.message;
                alert(`Failed to fetch location: ${errorMsg}`);
            });
        }

        function highlightArea(locationData, isStart = false, isEnd = false) {
            const { cellWidth, cellHeight } = getCellSize();
            
            if (!isStart && !isEnd) {
                const existingHighlights = document.querySelectorAll(".temp-highlight");
                existingHighlights.forEach(highlight => highlight.remove());
            }
            
            const highlight = document.createElement("div");
            if (locationData.room_number) {
                highlight.className = isStart ? "start-highlight" : isEnd ? "end-highlight" : "temp-highlight";
                highlight.innerHTML = `<span class="room-label">${locationData.room_number}</span>`;
            } else if (locationData.facility_number) {
                highlight.className = isStart ? "start-highlight" : isEnd ? "end-highlight" : "temp-highlight";
                highlight.innerHTML = `<span class="facility-label">${locationData.facility_number}</span>`;
            }
            
            const width = (locationData.x_max - locationData.x_min + 1) * cellWidth;
            const height = (locationData.y_max - locationData.y_min + 1) * cellHeight;
            
            highlight.style.left = `${locationData.x_min * cellWidth}px`;
            highlight.style.top = `${locationData.y_min * cellHeight}px`;
            highlight.style.width = `${width}px`;
            highlight.style.height = `${height}px`;
            
            highlightsContainer.appendChild(highlight);
        }

        function clearSelections(clearAll = false) {
            selectedStart = null;
            selectedEnd = null;
            selectingStart = false;
            selectingEnd = false;
            
            if (clearAll) {
                highlightsContainer.innerHTML = '';
                document.querySelectorAll(".start-highlight, .end-highlight, .temp-highlight, .path-marker").forEach(el => el.remove());
            } else {
                document.querySelectorAll(".temp-highlight").forEach(el => el.remove());
            }
        }

        function showDropdownMessage(message) {
            const messageBox = document.createElement("div");
            messageBox.className = "dropdown-message";
            messageBox.textContent = message;
            
            const button = selectingStart ? document.getElementById("start-location") : 
                        selectingEnd ? document.getElementById("end-location") :
                        document.getElementById("start-navigation");
            
            const rect = button.getBoundingClientRect();
            messageBox.style.left = `${rect.left}px`;
            messageBox.style.top = `${rect.bottom + 5}px`;
            
            document.body.appendChild(messageBox);
            
            setTimeout(() => {
                messageBox.remove();
            }, 3000);
        }

        function calculatePath(startCoords, endCoords) {
            fetch(`/api/getPath?startX=${startCoords.x}&startY=${startCoords.y}&endX=${endCoords.x}&endY=${endCoords.y}&floor=${currentFloor}`)
                .then(res => {
                    const contentType = res.headers.get('content-type');
                    if (!res.ok || !contentType || !contentType.includes('application/json')) {
                        return res.text().then(text => {
                            throw new Error(text || 'Path calculation failed');
                        });
                    }
                    return res.json();
                })
                .then(pathData => {
                    if (pathData && pathData.path) {
                        highlightPath(pathData.path);
                        if (selectedStart) highlightArea(selectedStart, true, false);
                        if (selectedEnd) highlightArea(selectedEnd, false, true);
                    } else {
                        alert("No valid path found.");
                    }
                })
                .catch(err => {
                    console.error("Error fetching path:", err);
                    alert("Failed to calculate path. Please try again.");
                });
        }

        function highlightPath(path) {
            document.querySelectorAll(".path-marker").forEach(marker => marker.remove());
                
            const { cellWidth, cellHeight } = getCellSize();
                
            path.forEach(coord => {
                const pathMarker = document.createElement("div");
                pathMarker.className = "path-marker";
                pathMarker.style.left = `${coord.x * cellWidth + cellWidth/2}px`;
                pathMarker.style.top = `${coord.y * cellHeight + cellHeight/2}px`;
                highlightsContainer.appendChild(pathMarker);
            });
        }

        // Initialize buttons with null checks
        floor2Btn.addEventListener("click", () => changeFloor(2));
        floor3Btn.addEventListener("click", () => changeFloor(3));

        const startLocationBtn = document.getElementById("start-location");
        const endLocationBtn = document.getElementById("end-location");
        const startNavigationBtn = document.getElementById("start-navigation");
        const endNavigationBtn = document.getElementById("end-navigation");

        if (startLocationBtn) {
            startLocationBtn.addEventListener("click", () => {
                selectingStart = true;
                selectingEnd = false;
                document.querySelectorAll(".start-highlight").forEach(el => el.remove());
                selectedStart = null;
                showDropdownMessage("Click on the floor plan to select START location");
            });
        }

        if (endLocationBtn) {
            endLocationBtn.addEventListener("click", () => {
                selectingStart = false;
                selectingEnd = true;
                document.querySelectorAll(".end-highlight").forEach(el => el.remove());
                selectedEnd = null;
                showDropdownMessage("Click on the floor plan to select END location");
            });
        }

        if (startNavigationBtn) {
            startNavigationBtn.addEventListener("click", () => {
                if (!selectedStart || !selectedEnd) {
                    showDropdownMessage("Please select both start and end locations first");
                    return;
                }
                
                const startName = selectedStart.room_number || selectedStart.facility_number || "selected start";
                const endName = selectedEnd.room_number || selectedEnd.facility_number || "selected end";
                
                const confirmationBox = document.createElement("div");
                confirmationBox.className = "navigation-confirmation";
                confirmationBox.innerHTML = `
                    <p>We will now navigate you from:</p>
                    <h3>${startName}</h3>
                    <p>to</p>
                    <h3>${endName}</h3>
                    <button id="confirm-navigation">Begin Navigation</button>
                    <button id="cancel-navigation">Cancel</button>
                `;
                
                document.body.appendChild(confirmationBox);
                
                const confirmHandler = () => {
                    confirmationBox.remove();
                    const startX = Math.floor((selectedStart.x_min + selectedStart.x_max) / 2);
                    const startY = Math.floor((selectedStart.y_min + selectedStart.y_max) / 2);
                    const endX = Math.floor((selectedEnd.x_min + selectedEnd.x_max) / 2);
                    const endY = Math.floor((selectedEnd.y_min + selectedEnd.y_max) / 2);
                    
                    calculatePath({ x: startX, y: startY }, { x: endX, y: endY });
                    showDropdownMessage(`Navigation started from ${startName} to ${endName}`);
                    document.getElementById("confirm-navigation").removeEventListener("click", confirmHandler);
                    document.getElementById("cancel-navigation").removeEventListener("click", cancelHandler);
                };
                
                const cancelHandler = () => {
                    confirmationBox.remove();
                    document.getElementById("confirm-navigation").removeEventListener("click", confirmHandler);
                    document.getElementById("cancel-navigation").removeEventListener("click", cancelHandler);
                };
                
                document.getElementById("confirm-navigation").addEventListener("click", confirmHandler);
                document.getElementById("cancel-navigation").addEventListener("click", cancelHandler);
            });
        }

        if (endNavigationBtn) {
            endNavigationBtn.addEventListener("click", () => {
                clearSelections(true);
                alert("Navigation ended. Start and end locations cleared.");
            });
        }

        // Initialize floor buttons
        floorBtns.forEach(btn => {
            btn.addEventListener("click", function() {
                floorBtns.forEach(b => b.classList.remove("active"));
                btn.classList.add("active");
                currentFloor = parseInt(btn.dataset.floor);
            });
        });
        
    } catch (err) {
        console.error("Floor navigation initialization failed:", err);
        alert("Map functionality unavailable. Please refresh the page.");
    }
});