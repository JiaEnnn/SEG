document.addEventListener("DOMContentLoaded", function () {
    // 1. Check if we're on the analytics page
    const analyticsContainer = document.querySelector(".analytics-container");
    if (!analyticsContainer) return;

    // 2. Fetch REAL booking data from API
    fetch('/api/bookings/analytics')
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(realBookingData => {
            // 3. Initialize Chart with real data
            initBookingChart(realBookingData);
            
            // 4. Generate recommendations
            generateRecommendations(realBookingData);
            
            // 5. Display user info (if available)
            displayUserInfo();
        })
        .catch(error => {
            console.error('Error loading analytics:', error);
            analyticsContainer.innerHTML = `
                <div class="error-message">
                    Failed to load analytics data. Please try again later.
                    <button onclick="window.location.reload()">Retry</button>
                </div>
            `;
        });

    // Dark Mode (should be in settings.js, but kept for compatibility)
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
    }
});

function initBookingChart(bookingData) {
    const ctx = document.getElementById("bookingChart")?.getContext("2d");
    if (!ctx) return;

    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                   "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    new Chart(ctx, {
        type: "bar",
        data: {
            labels: months,
            datasets: Object.keys(bookingData).map((room, index) => ({
                label: room,
                data: bookingData[room],
                backgroundColor: ["#ff6384", "#36a2eb", "#ffce56", "#4bc0c0"][index % 4],
                borderWidth: 1
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Bookings'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Month'
                    }
                }
            },
            plugins: {
                title: {
                    display: true,
                    text: 'Monthly Room Bookings',
                    font: {
                        size: 16
                    }
                }
            }
        }
    });
}

function generateRecommendations(bookingData) {
    const recommendationEl = document.getElementById("recommendationText");
    if (!recommendationEl) return;

    const lastMonthIndex = new Date().getMonth();
    let maxBookings = 0;
    let recommendedRoom = "";

    for (const room in bookingData) {
        const bookings = bookingData[room][lastMonthIndex];
        if (bookings > maxBookings) {
            maxBookings = bookings;
            recommendedRoom = room;
        }
    }

    recommendationEl.innerHTML = `
        <strong>Recommendation:</strong> Last month's most booked room was 
        <span class="highlight">${recommendedRoom}</span> with 
        <span class="highlight">${maxBookings}</span> bookings.
        Consider adding more availability slots for this room.
    `;
}

function displayUserInfo() {
    const userSection = document.querySelector(".user-info-section");
    if (!userSection) return;

    // In a real app, you would fetch this from /api/user/profile
    const dummyUser = {
        name: "John Doe",
        email: "johndoe@example.com",
        role: "Student",
        favoriteRoom: "Meeting Room",
        lastBooking: new Date().toLocaleDateString(),
        totalBookings: 15
    };

    userSection.innerHTML = `
        <div class="user-profile-card">
            <h3><i class="fas fa-user"></i> User Profile</h3>
            <div class="profile-detail">
                <span class="detail-label">Name:</span>
                <span>${dummyUser.name}</span>
            </div>
            <div class="profile-detail">
                <span class="detail-label">Email:</span>
                <span>${dummyUser.email}</span>
            </div>
            <div class="profile-detail">
                <span class="detail-label">Role:</span>
                <span>${dummyUser.role}</span>
            </div>
            <div class="profile-detail">
                <span class="detail-label">Favorite Room:</span>
                <span>${dummyUser.favoriteRoom}</span>
            </div>
            <div class="profile-detail">
                <span class="detail-label">Last Booking:</span>
                <span>${dummyUser.lastBooking}</span>
            </div>
            <div class="profile-detail">
                <span class="detail-label">Total Bookings:</span>
                <span>${dummyUser.totalBookings}</span>
            </div>
        </div>
    `;
}